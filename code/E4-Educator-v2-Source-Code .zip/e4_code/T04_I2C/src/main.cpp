// T04 — I2C fundamentals
// Scans bus, reads AHT20 temperature and humidity
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>

Adafruit_AHTX0 aht;

void i2cScan() {
  Serial.println("Scanning I2C bus...");
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0)
      Serial.printf("  Found device at 0x%02X\n", addr);
  }
  Serial.println("Scan complete.");
}

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  i2cScan();
  if (!aht.begin(&Wire)) {
    Serial.println("AHT20 not found!");
  } else {
    Serial.println("AHT20 OK.");
  }
  pinMode(LED_GREEN, OUTPUT);
}

void loop() {
  sensors_event_t h, t;
  aht.getEvent(&h, &t);
  Serial.printf("Temp: %.2f C  Humidity: %.1f%%\n",
                t.temperature, h.relative_humidity);
  digitalWrite(LED_GREEN, HIGH); delay(100); digitalWrite(LED_GREEN, LOW);
  delay(2000);
}
