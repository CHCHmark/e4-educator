// T03 — Buttons and debouncing
// Uses Button.h — copy from toolkit/ to src/
#include <Arduino.h>
#include "Button.h"

Button nextBtn(BTN_NEXT);
Button entBtn(BTN_ENT);

void setup() {
  Serial.begin(115200);
  nextBtn.begin();
  entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  pinMode(LED_RED,   OUTPUT); digitalWrite(LED_RED,   LOW);
  pinMode(LED_BLUE,  OUTPUT); digitalWrite(LED_BLUE,  LOW);
  Serial.println("T03 Buttons ready. NEXT=toggle green. ENT short=red. ENT long=blue.");
}

void loop() {
  Button::Event nextEv = nextBtn.read();
  Button::Event entEv  = entBtn.read();

  if (nextEv == Button::SHORT_PRESS) {
    bool s = digitalRead(LED_GREEN);
    digitalWrite(LED_GREEN, !s);
    Serial.println("NEXT short — GREEN toggled");
  }
  if (entEv == Button::SHORT_PRESS) {
    digitalWrite(LED_RED, !digitalRead(LED_RED));
    Serial.println("ENT short — RED toggled");
  }
  if (entEv == Button::LONG_PRESS) {
    digitalWrite(LED_BLUE, !digitalRead(LED_BLUE));
    Serial.println("ENT long — BLUE toggled");
  }
}
