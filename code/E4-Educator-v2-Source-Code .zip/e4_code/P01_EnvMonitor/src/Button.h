// Button.h — Fundrum E4 Educator reusable debounced button class
// Copy into src/ of any project that uses physical buttons
#pragma once
#include <Arduino.h>

class Button {
public:
  enum Event { NONE, SHORT_PRESS, LONG_PRESS };

  Button(int pin, unsigned long debounceMs = 50, unsigned long longMs = 700)
    : _pin(pin), _debounceMs(debounceMs), _longMs(longMs),
      _state(HIGH), _lastRaw(HIGH), _lastDebounce(0),
      _pressTime(0), _longFired(false), _lastEvent(NONE) {}

  void begin() { pinMode(_pin, INPUT_PULLUP); }

  Event read() {
    _lastEvent = NONE;
    bool raw = digitalRead(_pin);
    unsigned long now = millis();

    if (raw != _lastRaw) { _lastDebounce = now; _lastRaw = raw; }

    if (now - _lastDebounce >= _debounceMs) {
      if (raw != _state) {
        _state = raw;
        if (_state == LOW) {                   // Button pressed
          _pressTime  = now;
          _longFired  = false;
        } else {                               // Button released
          if (!_longFired)
            _lastEvent = SHORT_PRESS;
        }
      }
      // Long press fires once while held
      if (_state == LOW && !_longFired &&
          now - _pressTime >= _longMs) {
        _longFired = true;
        _lastEvent = LONG_PRESS;
      }
    }
    return _lastEvent;
  }

  Event lastEvent() const { return _lastEvent; }
  bool  isHeld()    const { return _state == LOW; }

private:
  int           _pin;
  unsigned long _debounceMs, _longMs;
  bool          _state, _lastRaw, _longFired;
  unsigned long _lastDebounce, _pressTime;
  Event         _lastEvent;
};
