// config.h — E4 Educator v2.0 Network Configuration
// ===================================================
// Edit this file with your WiFi and MQTT credentials.
// This file is shared across all network-enabled tutorials (T12-T16, P01-P05).
// Copy it into the src/ folder of each project alongside main.cpp.
//
// DO NOT commit this file to a public git repository.

#pragma once

// ── WiFi credentials ──────────────────────────────────────────────────────────
#define DEFAULT_SSID    "your_ssid"
#define DEFAULT_PASS    "your_wifi_password"

// ── MQTT broker (MarkPi3 at 192.168.1.79) ────────────────────────────────────
#define DEFAULT_BROKER  "192.168.1.79"
