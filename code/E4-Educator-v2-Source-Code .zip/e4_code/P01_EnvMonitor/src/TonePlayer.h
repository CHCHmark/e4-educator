// TonePlayer.h — Fundrum E4 Educator non-blocking tone sequencer
// Copy into src/ of any project that uses the piezo buzzer
#pragma once
#include <Arduino.h>

struct ToneNote {
  int freqHz;       // 0 = rest/silence
  int durationMs;
};

class TonePlayer {
public:
  TonePlayer(int pin, int channel = 1, int resolution = 8)
    : _pin(pin), _ch(channel), _res(resolution),
      _playing(false), _noteIdx(0), _noteStart(0),
      _sequence(nullptr), _seqLen(0) {}

  void begin() {
    ledcSetup(_ch, 1000, _res);
    ledcAttachPin(_pin, _ch);
    ledcWrite(_ch, 0);
  }

  // Start playing a sequence (non-blocking — call update() every loop)
  void play(const ToneNote* seq, int len) {
    _sequence  = seq;
    _seqLen    = len;
    _noteIdx   = 0;
    _playing   = true;
    _noteStart = millis();
    _startNote(0);
  }

  void stop() { _playing = false; ledcWrite(_ch, 0); }
  bool isPlaying() const { return _playing; }

  // Must be called every loop() pass
  void update() {
    if (!_playing) return;
    unsigned long now = millis();
    if (now - _noteStart >= (unsigned long)_sequence[_noteIdx].durationMs) {
      _noteIdx++;
      if (_noteIdx >= _seqLen) { stop(); return; }
      _noteStart = now;
      _startNote(_noteIdx);
    }
  }

private:
  int   _pin, _ch, _res;
  bool  _playing;
  int   _noteIdx, _seqLen;
  unsigned long _noteStart;
  const ToneNote* _sequence;

  void _startNote(int idx) {
    int freq = _sequence[idx].freqHz;
    if (freq == 0) { ledcWrite(_ch, 0); }
    else {
      ledcSetup(_ch, freq, _res);
      ledcAttachPin(_pin, _ch);
      ledcWrite(_ch, 128);    // 50% duty = clean square wave
    }
  }
};
