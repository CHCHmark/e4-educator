// TouchZone.h — Fundrum E4 Educator reusable touch zone class
// Copy into src/ of any project that uses XPT2046 touch
#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>

class TouchZone {
public:
  TouchZone() : _x(0), _y(0), _w(0), _h(0),
                _label(""), _active(true),
                _lastTap(0), _debounceMs(300) {}

  TouchZone(int x, int y, int w, int h,
            const char* label = "",
            unsigned long debounceMs = 300)
    : _x(x), _y(y), _w(w), _h(h),
      _label(label), _active(true),
      _lastTap(0), _debounceMs(debounceMs) {}

  // Returns true once per tap (debounced)
  bool isTapped(uint16_t tx, uint16_t ty, bool touched) {
    if (!_active || !touched) return false;
    if (tx < _x || tx > _x + _w) return false;
    if (ty < _y || ty > _y + _h) return false;
    unsigned long now = millis();
    if (now - _lastTap < _debounceMs) return false;
    _lastTap = now;
    return true;
  }

  // Containment check without debounce (for drag/held)
  bool contains(uint16_t tx, uint16_t ty) const {
    return (tx >= _x && tx <= _x + _w && ty >= _y && ty <= _y + _h);
  }

  void setActive(bool active) { _active = active; }
  bool isActive()    const { return _active; }
  const char* label() const { return _label; }

  // Draw button into a sprite (sprite-local coordinates)
  void draw(TFT_eSprite& spr, uint16_t bgCol,
            uint16_t borderCol, uint16_t textCol,
            int sprOffsetX = 0, int sprOffsetY = 0) {
    int sx = _x - sprOffsetX;
    int sy = _y - sprOffsetY;
    spr.fillRoundRect(sx, sy, _w, _h, 6, bgCol);
    spr.drawRoundRect(sx, sy, _w, _h, 6, borderCol);
    spr.setTextColor(textCol, bgCol);
    spr.setTextSize(1);
    int tw = strlen(_label) * 6;
    int th = 8;
    spr.setCursor(sx + (_w - tw) / 2, sy + (_h - th) / 2);
    spr.print(_label);
  }

private:
  int  _x, _y, _w, _h;
  const char* _label;
  bool _active;
  unsigned long _lastTap, _debounceMs;
};
