// Settings.h — Fundrum E4 Educator NVS settings manager
// Copy into src/ of any project that uses persistent settings
#pragma once
#include <Arduino.h>
#include <Preferences.h>

// ── NVS key constants — ALL ≤15 characters ────────────────────────────────
#define NVS_NS_DISP   "display"
#define NVS_NS_ALERT  "alerts"
#define NVS_NS_DEV    "device"
#define NVS_NS_NET    "network"

#define NVS_BRIGHT    "brightness"   // 10 ✓
#define NVS_DIM_IDLE  "dimOnIdle"    //  9 ✓
#define NVS_TEMP_HI   "tempAlert"    //  9 ✓
#define NVS_HUMID_HI  "humidAlert"   // 10 ✓
#define NVS_PRESS_AL  "pressAlert"   // 10 ✓
#define NVS_LOG_EN    "logEnable"    //  9 ✓
#define NVS_INTERVAL  "logInterval"  // 11 ✓
#define NVS_BOOTS     "bootCount"    //  9 ✓
#define NVS_AUDIO_GAIN "audioGain"   //  9 ✓

struct Settings {
  // Display
  int   brightness  = 200;
  bool  dimOnIdle   = false;
  // Alerts
  float tempAlert   = 28.0f;
  float humidAlert  = 70.0f;
  float pressAlert  = 980.0f;
  // Logger
  bool  logEnable   = true;
  unsigned long logInterval = 5000;
  // Audio
  float audioGain   = 1.0f;
  // Device
  unsigned long bootCount = 0;
};

class SettingsManager {
public:
  Settings s;

  void load() {
    Preferences p;
    p.begin(NVS_NS_DISP, true);
    s.brightness = p.getInt(NVS_BRIGHT,   s.brightness);
    s.dimOnIdle  = p.getBool(NVS_DIM_IDLE, s.dimOnIdle);
    p.end();

    p.begin(NVS_NS_ALERT, true);
    s.tempAlert  = p.getFloat(NVS_TEMP_HI,  s.tempAlert);
    s.humidAlert = p.getFloat(NVS_HUMID_HI, s.humidAlert);
    s.pressAlert = p.getFloat(NVS_PRESS_AL, s.pressAlert);
    p.end();

    p.begin(NVS_NS_DEV, true);
    s.logEnable   = p.getBool(NVS_LOG_EN,    s.logEnable);
    s.logInterval = p.getULong(NVS_INTERVAL, s.logInterval);
    s.audioGain   = p.getFloat(NVS_AUDIO_GAIN, s.audioGain);
    s.bootCount   = p.getULong(NVS_BOOTS, 0) + 1;
    p.end();

    _saveBootCount();
    Serial.printf("Settings loaded. Boot #%lu\n", s.bootCount);
  }

  void save() {
    Preferences p;
    p.begin(NVS_NS_DISP, false);
    p.putInt(NVS_BRIGHT,    s.brightness);
    p.putBool(NVS_DIM_IDLE, s.dimOnIdle);
    p.end();

    p.begin(NVS_NS_ALERT, false);
    p.putFloat(NVS_TEMP_HI,  s.tempAlert);
    p.putFloat(NVS_HUMID_HI, s.humidAlert);
    p.putFloat(NVS_PRESS_AL, s.pressAlert);
    p.end();

    p.begin(NVS_NS_DEV, false);
    p.putBool(NVS_LOG_EN,     s.logEnable);
    p.putULong(NVS_INTERVAL,  s.logInterval);
    p.putFloat(NVS_AUDIO_GAIN,s.audioGain);
    p.end();

    Serial.println("Settings saved.");
  }

  void reset() {
    Preferences p;
    p.begin(NVS_NS_DISP,  false); p.clear(); p.end();
    p.begin(NVS_NS_ALERT, false); p.clear(); p.end();
    p.begin(NVS_NS_DEV,   false); p.clear(); p.end();
    p.begin(NVS_NS_NET,   false); p.clear(); p.end();
    s = Settings();
    Serial.println("Factory reset complete.");
  }

  void print() const {
    Serial.printf("  Brightness:   %d\n",     s.brightness);
    Serial.printf("  TempAlert:    %.1f C\n",  s.tempAlert);
    Serial.printf("  HumidAlert:   %.1f%%\n",  s.humidAlert);
    Serial.printf("  PressAlert:   %.1f hPa\n",s.pressAlert);
    Serial.printf("  LogEnable:    %s\n",      s.logEnable ? "yes" : "no");
    Serial.printf("  LogInterval:  %lums\n",   s.logInterval);
    Serial.printf("  AudioGain:    x%.0f\n",   s.audioGain);
    Serial.printf("  BootCount:    %lu\n",     s.bootCount);
  }

private:
  void _saveBootCount() {
    Preferences p;
    p.begin(NVS_NS_DEV, false);
    p.putULong(NVS_BOOTS, s.bootCount);
    p.end();
  }
};
