// P01 — Environmental Monitor
// Full implementation — see P01 project document.
// Required files in src/: Button.h TonePlayer.h TouchZone.h Settings.h
// From toolkit/: copy all 5 .h files into src/
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <TFT_eSPI.h>
#include <Adafruit_AHTX0.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include <LittleFS.h>
#include <ESPAsyncWebServer.h>
#include <ElegantOTA.h>
#include <esp_ota_ops.h>
#include "Button.h"
#include "TonePlayer.h"
#include "TouchZone.h"
#include "Settings.h"
#include "config.h"    // WiFi/MQTT credentials — edit this file

// See P01 document sections 4-8 for full module implementations.
// main.cpp coordinator pattern shown below.

TFT_eSPI    tft;
TFT_eSprite spr = TFT_eSprite(&tft);
SettingsManager settings;
Button      nextBtn(BTN_NEXT);
Button      entBtn(BTN_ENT);
TonePlayer  tonePlayer(PIEZO);
Adafruit_AHTX0 aht;
OneWire ow(ONE_WIRE); DallasTemperature ds(&ow);
WiFiClient wifiClient; PubSubClient mqtt(wifiClient);
AsyncWebServer server(80);

// ── State ─────────────────────────────────────────────────────────────
float ahtTempC=0, ahtHumid=0, ds18TempC=-99;
int   lightPct=0; long readCount=0;
bool  sdOk=false, logEnabled=true, webStarted=false, otaValid=false;
unsigned long lastSensorRead=0, lastFooter=0;

void setup() {
  Serial.begin(115200);
  Serial.printf("P01 Env Monitor FW:%s\n", FW_VERSION);
  settings.load();

  pinMode(LED_GREEN,OUTPUT); digitalWrite(LED_GREEN,LOW);
  pinMode(LED_RED,  OUTPUT); digitalWrite(LED_RED,  LOW);
  pinMode(LED_BLUE, OUTPUT); digitalWrite(LED_BLUE, LOW);

  // TFT FIRST
  pinMode(TFT_BL,OUTPUT); digitalWrite(TFT_BL,LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(0x0000);
  ledcSetup(0,5000,8); ledcAttachPin(TFT_BL,0);
  ledcWrite(0, settings.s.brightness);
  spr.setColorDepth(16); spr.createSprite(240,42);

  nextBtn.begin(); entBtn.begin(); tonePlayer.begin();
  Wire.begin(I2C_SDA, I2C_SCL);
  aht.begin(&Wire); ds.begin();

  // SD SECOND
  sdOk = SD.begin(SD_CS);
  if (!LittleFS.begin(true)) Serial.println("LittleFS failed.");

  // Implement: drawChrome(), initNetwork(), wifiConnect(), setupWebServer()
  // See P01 document for complete implementations.

  digitalWrite(LED_GREEN, HIGH);
  Serial.println("P01 ready. See document for full implementation.");
}

void loop() {
  unsigned long now = millis();
  // wifiUpdate(now); mqttUpdate(now); ElegantOTA.loop();
  // tonePlayer.update();
  // ... see P01 document loop() structure ...
  delay(5000);
  Serial.printf("Up: %lus\n", now/1000);
  if (!otaValid && now > 10000) {
    esp_ota_mark_app_valid_cancel_rollback();
    otaValid = true;
  }
}
