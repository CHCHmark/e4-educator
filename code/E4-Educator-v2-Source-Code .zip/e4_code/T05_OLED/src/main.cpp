// T05 — OLED display
// Multi-page sensor dashboard on SSD1306 128x64
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define OLED_W 128
#define OLED_H  64
Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
Adafruit_AHTX0   aht;

int  page = 0;
bool btnLast = HIGH;

void drawPage0(float t, float h) {
  oled.clearDisplay();
  oled.fillRect(0, 0, 128, 13, SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK); oled.setTextSize(1);
  oled.setCursor(2, 3); oled.print("E4 Env Monitor  1/2");
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(2); oled.setCursor(0, 18);
  oled.printf("%.1f C", t);
  oled.setTextSize(2); oled.setCursor(0, 40);
  oled.printf("%.1f%%", h);
  oled.display();
}

void drawPage1(float t, float h) {
  oled.clearDisplay();
  oled.fillRect(0, 0, 128, 13, SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK); oled.setTextSize(1);
  oled.setCursor(2, 3); oled.print("Statistics      2/2");
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 20); oled.printf("FW: %s", FW_VERSION);
  oled.setCursor(0, 35); oled.printf("Up: %lus", millis()/1000);
  oled.display();
}

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  aht.begin(&Wire);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(LED_GREEN, OUTPUT);
  digitalWrite(LED_GREEN, HIGH);
}

void loop() {
  sensors_event_t h, t;
  aht.getEvent(&h, &t);

  bool btnNow = digitalRead(BTN_NEXT);
  if (btnLast == HIGH && btnNow == LOW) {
    page = (page + 1) % 2;
    delay(50);
  }
  btnLast = btnNow;

  if (page == 0) drawPage0(t.temperature, h.relative_humidity);
  else           drawPage1(t.temperature, h.relative_humidity);
  delay(1000);
}
