// T07 — Audio output basics — Tier 1 Consolidation Project
// Alert station: AHT20 + LDR + OLED + TonePlayer + LEDs + buttons
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "Button.h"
#include "TonePlayer.h"

// Copy Button.h and TonePlayer.h from toolkit/ into src/

#define OLED_ADDR 0x3C
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
Adafruit_AHTX0   aht;
Button           nextBtn(BTN_NEXT);
Button           entBtn(BTN_ENT);
TonePlayer       piezo(PIEZO);

const ToneNote STARTUP[] = {{262,120},{330,120},{392,120},{523,250}};
const ToneNote ALERT[]   = {{880,80},{0,40},{880,80},{0,40},{880,200}};

const float TEMP_ALERT  = 28.0f;
const float HUMID_ALERT = 70.0f;

float tempC = 0, humidity = 0;
bool  alertActive = false;
unsigned long lastRead = 0;
const unsigned long READ_INTERVAL = 5000;

int readLDR() {
  long t = 0;
  for (int i = 0; i < 8; i++) { t += analogRead(LDR); delay(2); }
  return constrain(map(t/8, 200, 3800, 0, 100), 0, 100);
}

void updateOLED(int lightPct) {
  oled.clearDisplay();
  oled.fillRect(0,0,128,13,SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK); oled.setTextSize(1);
  oled.setCursor(2,3);
  oled.print(alertActive ? "! ALERT !" : "E4 Alert Station");
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(2); oled.setCursor(0,18);
  oled.printf("%.1fC", tempC);
  oled.setTextSize(2); oled.setCursor(0,38);
  oled.printf("%.1f%%", humidity);
  oled.display();
}

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  aht.begin(&Wire);
  nextBtn.begin(); entBtn.begin(); piezo.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  pinMode(LED_RED,   OUTPUT); digitalWrite(LED_RED,   LOW);
  pinMode(LED_BLUE,  OUTPUT); digitalWrite(LED_BLUE,  LOW);
  piezo.play(STARTUP, sizeof(STARTUP)/sizeof(STARTUP[0]));
  digitalWrite(LED_GREEN, HIGH);
  Serial.println("T07 ready.");
}

void loop() {
  unsigned long now = millis();
  piezo.update();
  Button::Event nextEv = nextBtn.read();
  Button::Event entEv  = entBtn.read();

  if (now - lastRead >= READ_INTERVAL) {
    lastRead = now;
    sensors_event_t h, t;
    aht.getEvent(&h, &t);
    tempC    = t.temperature;
    humidity = h.relative_humidity;
    int ldr  = readLDR();
    bool alert = (tempC > TEMP_ALERT || humidity > HUMID_ALERT);
    if (alert && !alertActive) {
      alertActive = true;
      digitalWrite(LED_BLUE, HIGH);
      piezo.play(ALERT, sizeof(ALERT)/sizeof(ALERT[0]));
    }
    if (!alert) { alertActive = false; digitalWrite(LED_BLUE, LOW); }
    updateOLED(ldr);
    Serial.printf("T:%.1f H:%.1f L:%d Alert:%s\n",
                  tempC, humidity, ldr, alertActive?"YES":"no");
  }
  if (entEv == Button::SHORT_PRESS && alertActive) {
    alertActive = false; piezo.stop();
    digitalWrite(LED_BLUE, LOW);
  }
}
