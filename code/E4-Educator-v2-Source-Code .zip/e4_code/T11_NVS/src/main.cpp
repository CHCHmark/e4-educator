// T11 — NVS Persistence (Settings.h)
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - Preferences (NVS) — namespace, keys ≤15 chars
//   - Settings.h — load(), save(), reset(), print()
//   - Boot counter — increments every power cycle
//   - Editable settings via NEXT (cycle) + ENT (adjust)
//   - Factory reset — hold both buttons at boot
//   - TFT settings display with live editing feedback

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "Button.h"
#include "Settings.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_SEL     0x2965   // Selected row highlight

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

TFT_eSPI       tft;
TFT_eSprite    spr = TFT_eSprite(&tft);
Button         nextBtn(BTN_NEXT);
Button         entBtn(BTN_ENT);
SettingsManager settings;

int     selectedRow = 0;
bool    editMode    = false;

struct SettRow {
  const char* label;
  const char* unit;
  int         value;
  int         minVal;
  int         maxVal;
  int         step;
};

SettRow rows[4] = {
  { "Brightness",   "/255", 200,   40, 255,  10 },
  { "Temp alert",   "C",     28,   15,  45,   1 },
  { "Humid alert",  "%",     70,   30,  99,   5 },
  { "Log interval", "s",      5,    1,  60,   1 },
};
const int NUM_ROWS = 4;

void loadRows() {
  rows[0].value = settings.s.brightness;
  rows[1].value = (int)settings.s.tempAlert;
  rows[2].value = (int)settings.s.humidAlert;
  rows[3].value = (int)(settings.s.logInterval / 1000);
}

void saveRows() {
  settings.s.brightness   = rows[0].value;
  settings.s.tempAlert    = (float)rows[1].value;
  settings.s.humidAlert   = (float)rows[2].value;
  settings.s.logInterval  = (unsigned long)rows[3].value * 1000;
  settings.save();
}

void drawChrome() {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print("T11  NVS Settings");
  tft.setTextSize(1);
  tft.setTextColor(COL_LABEL, COL_HEADER);
  tft.setCursor(248, 9);
  tft.printf("Boot #%lu", settings.s.bootCount);
  tft.setCursor(248, 22);
  tft.printf("FW:%s", FW_VERSION);

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 206);
  tft.print("NEXT=select  ENT=edit/save  NEXT-long=reset");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawSettings() {
  spr.fillSprite(COL_BG);

  for (int i = 0; i < NUM_ROWS; i++) {
    int y = i * 36 + 4;
    bool sel  = (i == selectedRow);
    bool edit = sel && editMode;
    uint16_t bg = edit ? 0x0A29 : sel ? COL_SEL : COL_BG;

    spr.fillRect(0, y, SCR_W, 34, bg);
    spr.drawFastHLine(0, y + 34, SCR_W, COL_LABEL);

    // Label
    spr.setTextColor(COL_LABEL, bg);
    spr.setTextSize(1);
    spr.setCursor(8, y + 6);
    spr.print(rows[i].label);

    // Value — large
    spr.setTextColor(edit ? COL_ACCENT : (sel ? COL_TEXT : COL_TEXT), bg);
    spr.setTextSize(2);
    spr.setCursor(200, y + 8);
    spr.printf("%d %s", rows[i].value, rows[i].unit);

    // Edit indicator
    if (edit) {
      spr.setTextColor(COL_ACCENT, bg);
      spr.setTextSize(1);
      spr.setCursor(8, y + 20);
      spr.printf("ENT=save  NEXT=+%d  (range %d-%d)",
                 rows[i].step, rows[i].minVal, rows[i].maxVal);
    }
  }

  // NVS info block
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 152);
  spr.printf("NVS namespace: 'device'  |  Keys ≤15 chars");

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void setup() {
  Serial.begin(115200);

  // Factory reset check — hold both buttons at power-on
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_ENT,  INPUT_PULLUP);
  if (digitalRead(BTN_NEXT) == LOW && digitalRead(BTN_ENT) == LOW) {
    settings.reset();
    Serial.println("Factory reset triggered!");
  }

  settings.load();
  settings.print();
  Serial.printf("T11 NVS Settings FW:%s  Boot#%lu\n",
                FW_VERSION, settings.s.bootCount);

  nextBtn.begin(); entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0);
  ledcWrite(0, settings.s.brightness);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  loadRows();
  drawChrome();
  drawSettings();
  digitalWrite(LED_GREEN, HIGH);
}

void loop() {
  Button::Event nextEv = nextBtn.read();
  Button::Event entEv  = entBtn.read();

  if (!editMode) {
    // Navigate rows
    if (nextEv == Button::SHORT_PRESS) {
      selectedRow = (selectedRow + 1) % NUM_ROWS;
      drawSettings();
    }
    // Enter edit mode
    if (entEv == Button::SHORT_PRESS) {
      editMode = true;
      drawSettings();
      Serial.printf("Editing: %s\n", rows[selectedRow].label);
    }
    // Long NEXT = factory reset
    if (nextEv == Button::LONG_PRESS) {
      settings.reset();
      loadRows();
      drawChrome();
      drawSettings();
      Serial.println("Factory reset.");
    }
  } else {
    // In edit mode: NEXT increments, ENT saves
    if (nextEv == Button::SHORT_PRESS) {
      rows[selectedRow].value += rows[selectedRow].step;
      if (rows[selectedRow].value > rows[selectedRow].maxVal)
        rows[selectedRow].value = rows[selectedRow].minVal;
      // Apply brightness live
      if (selectedRow == 0) ledcWrite(0, rows[0].value);
      drawSettings();
    }
    if (entEv == Button::SHORT_PRESS) {
      editMode = false;
      saveRows();
      drawSettings();
      Serial.printf("Saved %s = %d\n",
                    rows[selectedRow].label, rows[selectedRow].value);
    }
  }
}
