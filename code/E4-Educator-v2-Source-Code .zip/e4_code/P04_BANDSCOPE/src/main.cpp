// P04 — BANDSCOPE Audio Analyser
// I2S MEMS microphone + FFT + four display modes + MQTT telemetry
// NOTE: GPIO 32 (MEMS_BCLK) = LED_BLUE — do NOT use LED_BLUE in this project.
// See P04 document for full dual-core FreeRTOS implementation.
// Copy Button.h and Settings.h from toolkit/ into src/.
#include <Arduino.h>
#include <driver/i2s.h>
#include <TFT_eSPI.h>
#include <arduinoFFT.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include "config.h"    // WiFi/MQTT credentials — edit this file
// ... see P04 document for complete AudioTask.h, Display.h, Network.h implementations
void setup() { Serial.begin(115200); Serial.println("P04 BANDSCOPE — see document."); }
void loop()  { delay(5000); }
