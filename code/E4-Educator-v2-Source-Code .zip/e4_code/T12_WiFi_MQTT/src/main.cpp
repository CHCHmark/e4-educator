// T12 — WiFi and MQTT
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - Non-blocking WiFi state machine
//   - PubSubClient MQTT — connect, publish, subscribe
//   - Last Will and Testament (LWT) — online/offline
//   - MQTT callback — incoming message updates TFT
//   - Retained publish — firmware version on connect
//   - TFT status display: WiFi RSSI, MQTT state, topics

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include "Button.h"
#include "config.h"    // WiFi/MQTT credentials — edit this file

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_ERR     0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

TFT_eSPI       tft;
TFT_eSprite    spr = TFT_eSprite(&tft);
Button         nextBtn(BTN_NEXT);
Button         entBtn(BTN_ENT);
WiFiClient     wifiClient;
PubSubClient   mqtt(wifiClient);

// ── Network config — set via build_flags ──────────────────────────────────────
const char* WIFI_SSID   = DEFAULT_SSID;
const char* WIFI_PASS   = DEFAULT_PASS;
const char* MQTT_BROKER = DEFAULT_BROKER;
const int   MQTT_PORT   = 1883;

// ── State machine ─────────────────────────────────────────────────────────────
enum WiFiSt { W_IDLE, W_CONNECTING, W_CONNECTED, W_FAILED };
WiFiSt     wifiState   = W_IDLE;
unsigned long wifiT    = 0;
unsigned long lastPublish = 0;
unsigned long pubCount = 0;
char lastRxTopic[48]   = "";
char lastRxMsg[64]     = "";

void mqttCallback(char* topic, byte* payload, unsigned int len) {
  String msg;
  for (unsigned int i = 0; i < min(len, (unsigned int)63); i++)
    msg += (char)payload[i];
  strncpy(lastRxTopic, topic, 47);
  strncpy(lastRxMsg,   msg.c_str(), 63);
  Serial.printf("[MQTT IN] %s = %s\n", topic, msg.c_str());

  // React to LED command
  if (String(topic) == "e4/cmd/led") {
    if (msg == "red")   { digitalWrite(LED_RED,   HIGH); digitalWrite(LED_GREEN, LOW); }
    if (msg == "green") { digitalWrite(LED_GREEN, HIGH); digitalWrite(LED_RED,   LOW); }
    if (msg == "off")   { digitalWrite(LED_RED,   LOW);  digitalWrite(LED_GREEN, LOW); }
  }
}

bool mqttConnect() {
  if (WiFi.status() != WL_CONNECTED) return false;
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  bool ok = mqtt.connect("e4-t12",
    nullptr, nullptr,              // no auth
    "e4/status", 1, true, "offline");  // LWT
  if (ok) {
    mqtt.publish("e4/status", "online", true);
    char fwMsg[32];
    snprintf(fwMsg, sizeof(fwMsg), "%s/%s", FW_VERSION, FW_DATE);
    mqtt.publish("e4/firmware", fwMsg, true);
    mqtt.subscribe("e4/cmd/#");
    Serial.printf("[MQTT] Connected to %s\n", MQTT_BROKER);
  }
  return ok;
}

void wifiUpdate(unsigned long now) {
  switch (wifiState) {
    case W_IDLE:
      WiFi.mode(WIFI_STA);
      WiFi.begin(WIFI_SSID, WIFI_PASS);
      wifiT = now;
      wifiState = W_CONNECTING;
      Serial.printf("WiFi connecting to %s...\n", WIFI_SSID);
      break;
    case W_CONNECTING:
      if (WiFi.status() == WL_CONNECTED) {
        wifiState = W_CONNECTED;
        Serial.printf("WiFi OK — IP: %s\n", WiFi.localIP().toString().c_str());
      } else if (now - wifiT > 15000) {
        wifiState = W_FAILED;
        wifiT = now;
        Serial.println("WiFi timeout.");
      }
      break;
    case W_CONNECTED:
      if (WiFi.status() != WL_CONNECTED) {
        wifiState = W_CONNECTING;
        wifiT = now;
        WiFi.reconnect();
      }
      break;
    case W_FAILED:
      if (now - wifiT > 30000) wifiState = W_IDLE;
      break;
  }
}

void mqttUpdate(unsigned long now) {
  if (wifiState != W_CONNECTED) return;
  if (!mqtt.connected()) {
    static unsigned long lastRetry = 0;
    if (now - lastRetry > 5000) { lastRetry = now; mqttConnect(); }
  }
  mqtt.loop();
}

void drawChrome() {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print("T12  WiFi + MQTT");
  tft.setTextSize(1);
  uint16_t wc = (wifiState == W_CONNECTED) ? COL_OK :
                (wifiState == W_CONNECTING) ? COL_WARN : COL_ERR;
  tft.setTextColor(wc, COL_HEADER);
  tft.setCursor(254, 9);
  tft.print(wifiState == W_CONNECTED  ? "WiFi OK" :
            wifiState == W_CONNECTING ? "WiFi..." : "No WiFi");
  tft.setTextColor(mqtt.connected() ? COL_OK : COL_LABEL, COL_HEADER);
  tft.setCursor(254, 22);
  tft.print(mqtt.connected() ? "MQTT OK" : "No MQTT");

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 206);
  tft.print("T12 WiFi/MQTT  |  ENT=publish now");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawStatus(unsigned long now) {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  auto row = [&](int y, const char* lbl, const String& val, uint16_t col=COL_TEXT) {
    spr.setTextColor(COL_LABEL, COL_BG); spr.setCursor(4,  y); spr.print(lbl);
    spr.setTextColor(col,       COL_BG); spr.setCursor(120, y); spr.print(val);
  };

  bool wok = (wifiState == W_CONNECTED);
  bool mok = mqtt.connected();

  row(4,  "WiFi SSID:",  WIFI_SSID,  wok ? COL_OK : COL_ERR);
  row(18, "IP address:", wok ? WiFi.localIP().toString() : "---");
  row(32, "RSSI:",       wok ? String(WiFi.RSSI()) + " dBm" : "---",
          wok ? (WiFi.RSSI() > -70 ? COL_OK : COL_WARN) : COL_LABEL);
  row(46, "MQTT broker:",MQTT_BROKER, mok ? COL_OK : COL_LABEL);
  row(60, "MQTT status:",mok ? "Connected" : "Disconnected", mok ? COL_OK : COL_ERR);
  row(74, "Published:",  String(pubCount) + " msgs", COL_ACCENT);
  row(88, "Uptime:",     String(now / 1000) + " s");

  // Last received
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setCursor(4, 110);
  spr.print("Last received:");
  spr.setTextColor(COL_TEXT, COL_BG);
  spr.setCursor(4, 124);
  if (strlen(lastRxTopic) > 0) {
    spr.printf("%-28s", lastRxTopic);
    spr.setCursor(4, 138);
    spr.printf("= %s", lastRxMsg);
  } else {
    spr.print("(nothing yet — subscribe to e4/cmd/#)");
  }

  // Tip
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 156);
  spr.print("Try: mosquitto_pub -t e4/cmd/led -m red");

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T12 WiFi+MQTT FW:%s\n", FW_VERSION);

  nextBtn.begin(); entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  pinMode(LED_RED,   OUTPUT); digitalWrite(LED_RED,   LOW);

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  drawChrome();
  drawStatus(0);
  digitalWrite(LED_GREEN, HIGH);
}

void loop() {
  unsigned long now = millis();
  wifiUpdate(now);
  mqttUpdate(now);

  Button::Event entEv = entBtn.read();

  // ENT = manual publish
  if (entEv == Button::SHORT_PRESS && mqtt.connected()) {
    char buf[32];
    snprintf(buf, sizeof(buf), "%.1f", 20.0f + pubCount * 0.1f);
    mqtt.publish("e4/sensor/value", buf, false);
    pubCount++;
    Serial.printf("[MQTT OUT] e4/sensor/value = %s\n", buf);
  }

  // Auto-publish every 10s
  if (now - lastPublish >= 10000 && mqtt.connected()) {
    lastPublish = now;
    char buf[16];
    snprintf(buf, sizeof(buf), "%lu", now / 1000);
    mqtt.publish("e4/uptime", buf, true);
    pubCount++;
  }

  // Status screen: redraw every 1s — values change slowly (WiFi RSSI, uptime)
  // This is a timed partial refresh, not an every-loop redraw
  // The 1s gate means ~1% CPU on drawing vs 100% without it
  static unsigned long lastDraw = 0;
  if (now - lastDraw >= 1000) {
    lastDraw = now;
    drawChrome();
    drawStatus(now);
  }
}
