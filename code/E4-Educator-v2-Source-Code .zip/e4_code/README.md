# E4 Educator v2.0 — Source Code Package
**Walark Electronics / Fundrum Engineering — May 2026**

## Contents

| Folder | Description |
|--------|-------------|
| `toolkit/` | Reusable .h files — copy into `src/` of any project |
| `T01_PlatformIO/` through `T16_I2S_Audio/` | Tutorial firmware (T01-T07 complete; T08-T16 with full platformio.ini and working stubs — see documents for full implementation) |
| `P01_EnvMonitor/` | Tier 3 Project 1 — Environmental Monitor |
| `P02_DataLogger/` | Tier 3 Project 2 — Data Logger (with Chart.js web dashboard) |
| `P03_SensorNetwork/master/` | Tier 3 Project 3 — WSN Master firmware |
| `P03_SensorNetwork/node/` | Tier 3 Project 3 — WSN Node firmware (flash with NODE_ID=1..4) |
| `P04_BANDSCOPE/` | Tier 3 Project 4 — BANDSCOPE Audio Analyser |
| `P05_TouchUI/` | Tier 3 Project 5 — Touch UI Controller |

## Quick start

1. Open any project folder in VS Code with PlatformIO installed.
2. Copy required toolkit files from `toolkit/` into the project `src/` folder.
3. Edit `platformio.ini` `monitor_port` and `upload_port` to match your COM port.
4. For network projects: update `DEFAULT_SSID`, `DEFAULT_PASS`, `DEFAULT_BROKER` in `build_flags`.
5. Build and upload (Ctrl+Alt+U).
6. For LittleFS projects: also run **Upload Filesystem Image** after firmware upload.

## Toolkit files

| File | Used from | Copy to |
|------|-----------|---------|
| `Button.h` | T03 | `src/` |
| `TonePlayer.h` | T07 | `src/` |
| `TouchZone.h` | T09 | `src/` |
| `Settings.h` | T11 | `src/` |
| `SensorPacket.h` | T15 | `src/` of master AND node |

## Platform requirements

- espressif32 @ **6.6.0** — always pinned
- TFT_eSPI @ **2.5.43** — always pinned
- PlatformIO + VS Code

## Default credentials

WiFi SSID: `your_ssid`  
MQTT broker: `192.168.1.79` (MarkPi3)  
Update passwords in `build_flags` before use.

---
*Walark Electronics · Fundrum Engineering · Christchurch, New Zealand*
