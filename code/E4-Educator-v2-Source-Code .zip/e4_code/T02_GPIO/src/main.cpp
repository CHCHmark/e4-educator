// T02 — GPIO and build_flags
// Demonstrates OUTPUT/INPUT_PULLUP, LEDC PWM auto-brightness
#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  Serial.printf("T02 GPIO  FW:%s\n", FW_VERSION);

  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED,   OUTPUT);
  pinMode(BTN_NEXT,  INPUT_PULLUP);

  // TFT backlight PWM via BC847 transistor
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, LOW);   // LOW before ledcSetup — always
  ledcSetup(0, 5000, 8);
  ledcAttachPin(TFT_BL, 0);
}

void loop() {
  // Auto-brightness: LDR controls backlight
  int ldrRaw = analogRead(LDR);
  int brightness = map(ldrRaw, 200, 3800, 255, 40);
  brightness = constrain(brightness, 40, 255);
  ledcWrite(0, brightness);

  // Button → LED
  bool btnPressed = (digitalRead(BTN_NEXT) == LOW);
  digitalWrite(LED_GREEN, btnPressed ? HIGH : LOW);

  delay(50);
}
