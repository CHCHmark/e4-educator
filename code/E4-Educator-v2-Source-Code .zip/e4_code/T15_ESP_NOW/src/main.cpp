// T15 — ESP-NOW
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - ESP-NOW send and receive on same device (loopback demo)
//   - SensorPacket.h — packed struct with CRC
//   - Peer registration — send to broadcast MAC
//   - onReceive() — copy+flag pattern (no processing in callback)
//   - Sequence number tracking — missed packet detection
//   - WIFI_STA mode + esp_wifi_set_channel() before esp_now_init()
//   - Two roles selectable via NEXT: SENDER or RECEIVER display

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "Button.h"
#include "SensorPacket.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_ERR     0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

#define ESPNOW_CHANNEL 1

TFT_eSPI    tft;
TFT_eSprite spr = TFT_eSprite(&tft);
Button      nextBtn(BTN_NEXT);
Button      entBtn(BTN_ENT);

// Broadcast MAC — sends to all ESP-NOW devices on channel
uint8_t broadcastMAC[] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

// ── Shared receive state (written in callback, read in loop) ─────────────────
volatile bool       newPacket = false;
SensorPacket        rxPkt;
uint32_t            rxCount   = 0;
uint32_t            rxMissed  = 0;
uint8_t             lastSeq   = 0;
bool                firstPkt  = true;

// ── Send state ───────────────────────────────────────────────────────────────
uint8_t  txSeq      = 0;
uint32_t txCount    = 0;
uint32_t txFail     = 0;
bool     lastSendOk = false;

int  currentPage = 0;  // 0=send demo, 1=rx stats

void ARDUINO_ISR_ATTR onReceive(const uint8_t* mac,
                                 const uint8_t* data, int len) {
  if (len != (int)sizeof(SensorPacket)) return;
  memcpy(&rxPkt, data, sizeof(SensorPacket));
  if (rxPkt.magic != PKT_MAGIC) return;
  if (!validateCRC(rxPkt)) return;
  if (!firstPkt) {
    uint8_t expected = lastSeq + 1;
    if (rxPkt.seqNum != expected)
      rxMissed += (uint8_t)(rxPkt.seqNum - expected);
  }
  lastSeq  = rxPkt.seqNum;
  firstPkt = false;
  rxCount++;
  newPacket = true;
}

void onSent(const uint8_t* mac, esp_now_send_status_t status) {
  lastSendOk = (status == ESP_NOW_SEND_SUCCESS);
  if (!lastSendOk) txFail++;
}

void drawChrome(const char* title) {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print(title);
  tft.setTextSize(1);
  tft.setTextColor(COL_ACCENT, COL_HEADER);
  tft.setCursor(250, 9);
  tft.printf("Ch:%d", ESPNOW_CHANNEL);
  tft.setTextColor(COL_LABEL, COL_HEADER);
  tft.setCursor(250, 22);
  tft.printf("FW:%s", FW_VERSION);

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 208);
  tft.print("T15 ESP-NOW  |  NEXT=view  ENT=send now");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawSendView(unsigned long now) {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  // My MAC
  spr.setTextColor(COL_LABEL, COL_BG); spr.setCursor(4,   4); spr.print("My MAC:");
  spr.setTextColor(COL_ACCENT,COL_BG); spr.setCursor(70,  4); spr.print(WiFi.macAddress());

  // Packet stats
  spr.setTextColor(COL_LABEL,COL_BG);  spr.setCursor(4,  22); spr.print("Sent:");
  spr.setTextColor(COL_OK,   COL_BG);  spr.setCursor(70, 22); spr.printf("%lu", txCount);
  spr.setTextColor(COL_LABEL,COL_BG);  spr.setCursor(4,  36); spr.print("Failed:");
  spr.setTextColor(txFail>0 ? COL_ERR : COL_OK, COL_BG);
  spr.setCursor(70, 36); spr.printf("%lu", txFail);
  spr.setTextColor(COL_LABEL,COL_BG);  spr.setCursor(4,  50); spr.print("Last TX:");
  spr.setTextColor(lastSendOk ? COL_OK : COL_ERR, COL_BG);
  spr.setCursor(70, 50); spr.print(lastSendOk ? "DELIVERED" : "FAIL");

  // Current packet preview
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setCursor(4, 72);
  spr.print("Next packet:");
  spr.setTextColor(COL_TEXT, COL_BG);
  spr.setCursor(4, 86);
  spr.printf("magic=0x%02X  ver=0x%02X  node=1  seq=%d",
             PKT_MAGIC, PKT_VERSION, txSeq + 1);
  spr.setCursor(4, 100);
  float t = 20.0f + 3.0f * sinf(now * 0.001f);
  spr.printf("temp=%.1f  humid=%.1f  light=%d",
             t, 55.0f, (int)((now/100) % 100));

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 124);
  spr.printf("Packet size: %u bytes  (ESP-NOW max: 250)", sizeof(SensorPacket));
  spr.setCursor(4, 138);
  spr.print("Broadcast MAC: FF:FF:FF:FF:FF:FF");

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 154);
  spr.print("Auto-send every 2s  |  ENT = send now");

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawRxView() {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  spr.setTextColor(COL_ACCENT, COL_BG); spr.setCursor(4, 4);
  spr.print("Received packets:");

  spr.setTextColor(COL_LABEL,COL_BG); spr.setCursor(4,  20); spr.print("Received:");
  spr.setTextColor(COL_OK,   COL_BG); spr.setCursor(100, 20); spr.printf("%lu", rxCount);
  spr.setTextColor(COL_LABEL,COL_BG); spr.setCursor(4,  34); spr.print("Missed:");
  spr.setTextColor(rxMissed > 0 ? COL_ERR : COL_OK, COL_BG);
  spr.setCursor(100, 34); spr.printf("%lu", rxMissed);

  if (rxCount > 0) {
    spr.setTextColor(COL_TEXT, COL_BG);
    spr.setCursor(4, 56); spr.printf("Last node:  %d", rxPkt.nodeId);
    spr.setCursor(4, 70); spr.printf("Seq:        %d", rxPkt.seqNum);
    spr.setCursor(4, 84); spr.printf("Temp:       %.1f C", rxPkt.tempC);
    spr.setCursor(4, 98); spr.printf("Humidity:   %.1f %%", rxPkt.humidity);
    spr.setCursor(4, 112); spr.printf("Light:      %d %%", rxPkt.lightPct);
    spr.setCursor(4, 126); spr.printf("Battery:    %d mV", rxPkt.batteryMv);
    spr.setCursor(4, 140); spr.printf("Uptime:     %lu s", rxPkt.uptimeSec);
    bool crcOk = validateCRC(rxPkt);
    spr.setTextColor(crcOk ? COL_OK : COL_ERR, COL_BG);
    spr.setCursor(4, 154); spr.printf("CRC: %s", crcOk ? "VALID" : "FAIL");
  } else {
    spr.setTextColor(COL_LABEL, COL_BG);
    spr.setCursor(4, 60);
    spr.print("No packets received yet.");
    spr.setCursor(4, 76);
    spr.print("(loopback: this device sends to itself)");
  }
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

SensorPacket buildPacket(unsigned long now) {
  SensorPacket pkt = {};
  pkt.magic     = PKT_MAGIC;
  pkt.version   = PKT_VERSION;
  pkt.nodeId    = 1;
  pkt.seqNum    = ++txSeq;
  pkt.tempC     = 20.0f + 3.0f * sinf(now * 0.001f);
  pkt.humidity  = 55.0f + 8.0f * cosf(now * 0.0007f);
  pkt.lightPct  = (now / 100) % 100;
  pkt.batteryMv = 3700;
  pkt.uptimeSec = now / 1000;
  pkt.crc       = calcCRC((uint8_t*)&pkt, sizeof(pkt));
  return pkt;
}

void sendPacket(unsigned long now) {
  SensorPacket pkt = buildPacket(now);
  esp_err_t result = esp_now_send(broadcastMAC, (uint8_t*)&pkt, sizeof(pkt));
  if (result == ESP_OK) txCount++;
  else txFail++;
  Serial.printf("[ESP-NOW TX] seq=%d T:%.1f H:%.1f %s\n",
    pkt.seqNum, pkt.tempC, pkt.humidity,
    result == ESP_OK ? "OK" : "FAIL");
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T15 ESP-NOW FW:%s\n", FW_VERSION);

  nextBtn.begin(); entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  // ESP-NOW init — WiFi before esp_now_init()
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  Serial.printf("MAC: %s  Channel: %d\n",
                WiFi.macAddress().c_str(), ESPNOW_CHANNEL);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed!");
    tft.setCursor(8, 100);
    tft.setTextColor(COL_ERR, COL_BG);
    tft.print("ESP-NOW init FAILED");
    while(1) delay(1000);
  }

  esp_now_register_send_cb(onSent);
  esp_now_register_recv_cb(onReceive);

  // Register broadcast peer
  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, broadcastMAC, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);

  drawChrome("T15  ESP-NOW");
  drawSendView(0);
  digitalWrite(LED_GREEN, HIGH);
  Serial.println("ESP-NOW ready — loopback demo");
}

void loop() {
  unsigned long now = millis();
  Button::Event nextEv = nextBtn.read();
  Button::Event entEv  = entBtn.read();

  if (nextEv == Button::SHORT_PRESS) {
    currentPage = (currentPage + 1) % 2;
    drawChrome(currentPage == 0 ? "T15  ESP-NOW Send" : "T15  ESP-NOW Receive");
  }

  if (entEv == Button::SHORT_PRESS) {
    sendPacket(now);
  }

  // Auto-send every 2 seconds
  static unsigned long lastSend = 0;
  if (now - lastSend >= 2000) {
    lastSend = now;
    sendPacket(now);
  }

  // Process received packet
  static unsigned long ledOffAt = 0;
  if (newPacket) {
    newPacket = false;
    digitalWrite(LED_GREEN, HIGH);
    ledOffAt = now + 50;               // brief flash — turn off after 50ms
    if (currentPage == 1) drawRxView();
  }
  if (ledOffAt && now >= ledOffAt) {
    digitalWrite(LED_GREEN, LOW);
    ledOffAt = 0;
  }

  // Redraw send view only after a packet send or every 500ms
  // (stats change only on send events — no point redrawing 20x/second)
  static unsigned long lastSendDraw = 0;
  if (currentPage == 0 && (now - lastSendDraw >= 500)) {
    lastSendDraw = now;
    drawSendView(now);
  } else if (currentPage == 1 && !newPacket) {
    static unsigned long lastRxDraw = 0;
    if (now - lastRxDraw >= 500) { lastRxDraw = now; drawRxView(); }
  }
}
