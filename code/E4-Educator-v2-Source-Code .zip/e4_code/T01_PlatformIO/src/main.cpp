// T01 — PlatformIO and the E4
// Demonstrates millis() timing, build_flags, Serial.printf()
#include <Arduino.h>

unsigned long lastBlink = 0;
bool ledState = false;

void setup() {
  Serial.begin(115200);
  Serial.printf("T01 PlatformIO  FW:%s  Built:%s\n", FW_VERSION, FW_DATE);

  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_RED,   OUTPUT);
  pinMode(LED_BLUE,  OUTPUT);
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_RED,   LOW);
  digitalWrite(LED_BLUE,  LOW);
}

void loop() {
  unsigned long now = millis();

  if (now - lastBlink >= 500) {
    lastBlink = now;
    ledState  = !ledState;
    digitalWrite(LED_GREEN, ledState ? HIGH : LOW);
    Serial.printf("Uptime: %lums  LED: %s\n", now, ledState ? "ON" : "OFF");
  }
}
