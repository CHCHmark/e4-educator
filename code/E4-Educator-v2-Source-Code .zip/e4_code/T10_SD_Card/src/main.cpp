// T10 — SD Card and File I/O
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - SD.begin(SD_CS) — AFTER tft.init() (critical rule)
//   - CSV data logging with millis() timestamp
//   - Reading file back and displaying on TFT
//   - File size and free space reporting
//   - BMP splash screen from SD (if SPLASH.BMP present)
//   - NEXT cycles views: WRITE / READ / INFO
//   - ENT toggles logging on/off

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include <TFT_eSPI.h>
#include "Button.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_ERR     0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

#define LOG_FILE   "/T10_LOG.CSV"
#define MAX_ROWS   200

TFT_eSPI    tft;
TFT_eSprite spr = TFT_eSprite(&tft);
Button      nextBtn(BTN_NEXT);
Button      entBtn(BTN_ENT);

bool sdOk      = false;
bool logActive = true;
int  logRows   = 0;
int  currentPage = 0;  // 0=log live, 1=read back, 2=SD info
bool newSample = true; // Set true when a new reading is ready to display

// Sample history — global so loop() can update independently of draw
float sampleHistory[64] = {};
int   sampleHistIdx     = 0;
unsigned long lastSampleTime = 0;
float currentVal = 20.0f;

// ── Simulated sensor value (sine wave — replace with real sensor) ─────────────
float fakeSensor(unsigned long now) {
  return 20.0f + 5.0f * sinf(now * 0.001f);
}

// ── Chrome ────────────────────────────────────────────────────────────────────
void drawChrome(const char* title) {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print(title);
  // SD status
  tft.setTextSize(1);
  tft.setTextColor(sdOk ? COL_OK : COL_ERR, COL_HEADER);
  tft.setCursor(250, 9);
  tft.print(sdOk ? "SD OK" : "NO SD");
  tft.setTextColor(logActive ? COL_OK : COL_LABEL, COL_HEADER);
  tft.setCursor(250, 22);
  tft.print(logActive ? "LOG ON" : "LOG OFF");

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 208);
  tft.print("T10 SD Card  |  NEXT=view  ENT=log toggle");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

// ── Page 0: live logging view ────────────────────────────────────────────────
void drawLogView() {
  // Draw uses global currentVal and sampleHistory — updated by loop()
  newSample = false;
  spr.fillSprite(COL_BG);

  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(3);
  spr.setCursor(8, 8);
  spr.printf("%.2f", currentVal);
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(8, 46);
  spr.print("simulated sensor value (sine wave)");

  // Scrolling bar chart from global history
  for (int i = 0; i < 64; i++) {
    int idx = (sampleHistIdx + i) % 64;
    int barH = (int)map((long)(sampleHistory[idx] * 10), 150, 250, 0, 80);
    barH = constrain(barH, 0, 80);
    int x = i * 5;
    uint16_t col = (i == 63) ? COL_ACCENT : COL_OK;
    spr.fillRect(x, 140 - barH, 4, barH, col);
  }

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 148);
  spr.printf("Rows logged: %d  |  File: %s", logRows, LOG_FILE);

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── Page 1: read last 10 rows from SD ────────────────────────────────────────
void drawReadView() {
  spr.fillSprite(COL_BG);
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 4);
  spr.print("Last entries from " LOG_FILE ":");

  if (!sdOk) {
    spr.setTextColor(COL_ERR, COL_BG);
    spr.setCursor(4, 20);
    spr.print("SD not mounted.");
    spr.pushSprite(0, ZONE_CONTENT_Y);
    return;
  }

  File f = SD.open(LOG_FILE);
  if (!f) {
    spr.setTextColor(COL_ERR, COL_BG);
    spr.setCursor(4, 20);
    spr.print("File not found.");
    spr.pushSprite(0, ZONE_CONTENT_Y);
    return;
  }

  // Collect all lines, show last 10
  String lines[10];
  int count = 0;
  while (f.available()) {
    String l = f.readStringUntil('\n');
    l.trim();
    if (l.length() > 0) {
      lines[count % 10] = l;
      count++;
    }
  }
  f.close();

  int startIdx = (count >= 10) ? (count % 10) : 0;
  int show     = min(count, 10);
  spr.setTextColor(COL_TEXT, COL_BG);
  for (int i = 0; i < show; i++) {
    int idx = (startIdx + i) % 10;
    spr.setCursor(4, 16 + i * 14);
    spr.print(lines[idx].substring(0, 42));
  }
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 150);
  spr.printf("Total rows: %d", count);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── Page 2: SD card info ──────────────────────────────────────────────────────
void drawInfoView() {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  if (!sdOk) {
    spr.setTextColor(COL_ERR, COL_BG);
    spr.setCursor(4, 4);
    spr.print("SD card not mounted.");
    spr.setCursor(4, 20);
    spr.print("Check: SD inserted? TFT init before SD.begin()?");
    spr.pushSprite(0, ZONE_CONTENT_Y);
    return;
  }

  uint8_t cardType = SD.cardType();
  const char* typeStr = cardType == CARD_MMC  ? "MMC"  :
                        cardType == CARD_SD   ? "SDSC" :
                        cardType == CARD_SDHC ? "SDHC" : "UNKNOWN";

  uint64_t cardMB = SD.cardSize() / (1024 * 1024);
  uint64_t usedMB = SD.usedBytes() / (1024 * 1024);
  uint64_t freeMB = cardMB - usedMB;

  auto row = [&](int y, const char* label, const char* val, uint16_t col=COL_TEXT) {
    spr.setTextColor(COL_LABEL, COL_BG); spr.setCursor(4,  y); spr.print(label);
    spr.setTextColor(col,       COL_BG); spr.setCursor(120, y); spr.print(val);
  };

  char buf[24];
  row(8,   "Card type:",  typeStr);
  snprintf(buf, sizeof(buf), "%llu MB", cardMB);
  row(24,  "Card size:",  buf);
  snprintf(buf, sizeof(buf), "%llu MB", usedMB);
  row(40,  "Used:",       buf);
  snprintf(buf, sizeof(buf), "%llu MB", freeMB);
  row(56,  "Free:",       buf, freeMB > 10 ? COL_OK : COL_ERR);

  // Log file info
  if (SD.exists(LOG_FILE)) {
    File f = SD.open(LOG_FILE);
    unsigned long sz = f.size();
    f.close();
    snprintf(buf, sizeof(buf), "%lu bytes", sz);
    row(80,  LOG_FILE,   buf, COL_ACCENT);
    snprintf(buf, sizeof(buf), "%d rows", logRows);
    row(96,  "Rows logged:", buf);
  } else {
    row(80, LOG_FILE, "not created yet", COL_LABEL);
  }

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 120);
  spr.print("Rule: SD.begin(SD_CS) AFTER tft.init()");
  spr.setCursor(4, 136);
  spr.print("SD_CS = GPIO 15  (10k pull-up fitted)");

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// Called every loop() — updates sample state and sets newSample flag
// Decoupled from draw so the display only redraws when data changes
void sampleTick(unsigned long now) {
  if (now - lastSampleTime < 500) return;
  lastSampleTime = now;
  currentVal = fakeSensor(now);
  sampleHistory[sampleHistIdx] = currentVal;
  sampleHistIdx = (sampleHistIdx + 1) % 64;
  if (logActive && sdOk) {
    char line[40];
    snprintf(line, sizeof(line), "%lu,%.2f", now, currentVal);
    File f = SD.open(LOG_FILE, FILE_APPEND);
    if (f) { f.println(line); f.close(); logRows++; }
  }
  newSample = true;  // Tell loop() the display needs updating
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T10 SD Card FW:%s\n", FW_VERSION);

  nextBtn.begin(); entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);

  // TFT FIRST — always
  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  // SD SECOND — after TFT
  sdOk = SD.begin(SD_CS);
  Serial.printf("SD: %s\n", sdOk ? "OK" : "FAILED");

  if (sdOk && !SD.exists(LOG_FILE)) {
    File f = SD.open(LOG_FILE, FILE_WRITE);
    if (f) { f.println("millis,value"); f.close(); }
  }

  drawChrome("T10  SD Card");
  drawLogView();
  digitalWrite(LED_GREEN, sdOk ? HIGH : LOW);
}

void loop() {
  unsigned long now = millis();
  Button::Event nextEv = nextBtn.read();
  Button::Event entEv  = entBtn.read();

  if (nextEv == Button::SHORT_PRESS) {
    currentPage = (currentPage + 1) % 3;
    const char* t[] = {"T10  SD Log", "T10  SD Read", "T10  SD Info"};
    drawChrome(t[currentPage]);
    if (currentPage == 1) drawReadView();
    if (currentPage == 2) drawInfoView();
  }
  if (entEv == Button::SHORT_PRESS) {
    logActive = !logActive;
    drawChrome(currentPage==0?"T10  SD Log":currentPage==1?"T10  SD Read":"T10  SD Info");
    Serial.printf("Logging %s\n", logActive ? "ON" : "OFF");
  }

  // Sample tick runs every loop but only fires every 500ms
  // Decoupled from draw — sampleTick sets newSample=true when data is ready
  sampleTick(now);

  // Redraw only when new sample arrived
  if (currentPage == 0 && newSample) drawLogView();
  delay(50);
}
