// T09 — Touch Input (XPT2046)
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - XPT2046 calibration stored to NVS
//   - TouchZone.h footer button bar
//   - Partial update pattern — only redraw regions that change
//     Static regions drawn once. Dynamic regions use small overlay sprites.
//   - Three regions identified:
//       STATIC:  Chrome header, footer buttons, target circles
//       DYNAMIC: Touch dot overlay (32x32 sprite follows finger)
//               Coordinate text line (overwritten in-place)
//   - This pattern eliminates flicker AND reduces CPU load
//   - Touch rotation 1 pairs with TFT rotation 3

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <Preferences.h>
#include "Button.h"
#include "TouchZone.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_ERR     0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

// ── Overlay sprite for touch dot — small, fast ────────────────────────────────
#define DOT_SPRITE_W   40
#define DOT_SPRITE_H   40

// ── Coordinate text region ───────────────────────────────────────────────────
#define COORD_TEXT_Y  (ZONE_CONTENT_Y + ZONE_CONTENT_H - 14)  // Bottom of content

TFT_eSPI    tft;
TFT_eSprite ftr = TFT_eSprite(&tft);   // Footer sprite
TFT_eSprite dot = TFT_eSprite(&tft);   // Small dot overlay sprite
Button      nextBtn(BTN_NEXT);

TouchZone tzRed  (  4, ZONE_FTR_Y+2, 96, 36, "RED");
TouchZone tzGreen(112, ZONE_FTR_Y+2, 96, 36, "GREEN");
TouchZone tzBlue (220, ZONE_FTR_Y+2, 96, 36, "BLUE");

uint16_t activeColour = COL_TEXT;
TouchZone* activeZone = nullptr;
bool     calibrated   = false;
uint16_t calData[5];

// Track previous dot position so we can erase it precisely
int  prevDotX   = -1;
int  prevDotY   = -1;
bool prevTouched = false;

// ── Calibration ───────────────────────────────────────────────────────────────
void loadCalibration() {
  Preferences p;
  p.begin("touch", true);
  if (p.getBytesLength("cal") == sizeof(calData)) {
    p.getBytes("cal", calData, sizeof(calData));
    tft.setTouch(calData);
    calibrated = true;
    Serial.println("Calibration loaded.");
  } else {
    Serial.println("No calibration — hold NEXT to calibrate.");
  }
  p.end();
}

void runCalibration() {
  tft.fillScreen(COL_BG);
  tft.setTextColor(COL_TEXT, COL_BG);
  tft.setTextSize(2); tft.setCursor(20, 100); tft.print("Touch calibration");
  tft.setTextSize(1); tft.setCursor(20, 130); tft.print("Tap the corners when prompted");
  delay(1500);
  // Touch rotation 1 pairs with TFT setRotation(3) on E4 Educator v2.0
  // If touch is misaligned after calibration: swap to setRotation(1) + touch rot 3
  tft.calibrateTouch(calData, TFT_WHITE, TFT_BLACK, 15);
  Preferences p;
  p.begin("touch", false);
  p.putBytes("cal", calData, sizeof(calData));
  p.end();
  tft.setTouch(calData);
  calibrated = true;
  Serial.println("Calibration saved.");
}

// ── Static regions — drawn ONCE ───────────────────────────────────────────────

void drawStaticChrome() {
  // Header
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2); tft.setCursor(8, 9); tft.print("T09  Touch Input");
  tft.setTextSize(1);
  tft.setTextColor(calibrated ? COL_OK : COL_ERR, COL_HEADER);
  tft.setCursor(240, 9); tft.print(calibrated ? "CAL OK" : "NO CAL");
  tft.setTextColor(COL_LABEL, COL_HEADER);
  tft.setCursor(240, 22); tft.printf("FW:%s", FW_VERSION);
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawStaticContent() {
  // Content zone background — fill once
  tft.fillRect(0, ZONE_CONTENT_Y, SCR_W, ZONE_CONTENT_H, COL_BG);

  // Target circles — static, never change
  tft.drawCircle( 60, ZONE_CONTENT_Y+ 60, 30, COL_LABEL);
  tft.drawCircle( 60, ZONE_CONTENT_Y+ 60,  5, COL_LABEL);
  tft.drawCircle(260, ZONE_CONTENT_Y+ 60, 30, COL_LABEL);
  tft.drawCircle(260, ZONE_CONTENT_Y+ 60,  5, COL_LABEL);
  tft.drawCircle( 60, ZONE_CONTENT_Y+120, 30, COL_LABEL);
  tft.drawCircle( 60, ZONE_CONTENT_Y+120,  5, COL_LABEL);
  tft.drawCircle(260, ZONE_CONTENT_Y+120, 30, COL_LABEL);
  tft.drawCircle(260, ZONE_CONTENT_Y+120,  5, COL_LABEL);
  tft.drawCircle(160, ZONE_CONTENT_Y+ 82, 30, COL_ACCENT);
  tft.drawCircle(160, ZONE_CONTENT_Y+ 82,  5, COL_ACCENT);

  // Static hint text
  tft.setTextColor(COL_LABEL, COL_BG);
  tft.setTextSize(1);
  tft.setCursor(4, COORD_TEXT_Y);
  tft.print("Tap the display  |  Footer = colour");

  // Reset dot tracking
  prevDotX    = -1;
  prevDotY    = -1;
  prevTouched = false;
}

void drawStaticFooter() {
  ftr.fillSprite(COL_FOOTER);
  uint16_t rBg = (activeZone == &tzRed)   ? COL_ERR : 0x6000;
  uint16_t gBg = (activeZone == &tzGreen) ? COL_OK  : 0x0280;
  uint16_t bBg = (activeZone == &tzBlue)  ? 0x001F  : 0x000C;
  tzRed.draw  (ftr, rBg, COL_TEXT, COL_TEXT, 0, ZONE_FTR_Y);
  tzGreen.draw(ftr, gBg, COL_TEXT, COL_TEXT, 0, ZONE_FTR_Y);
  tzBlue.draw (ftr, bBg, COL_TEXT, COL_TEXT, 0, ZONE_FTR_Y);
  ftr.setTextColor(COL_LABEL, COL_FOOTER);
  ftr.setTextSize(1); ftr.setCursor(4, 26); ftr.print("NEXT-long=calibrate");
  ftr.pushSprite(0, ZONE_FTR_Y);
}

// ── Dynamic region 1 — touch dot ──────────────────────────────────────────────
// Uses a small 40x40 sprite pushed only at the touch location.
// Previous position is erased by redrawing the background beneath it.

void eraseDot() {
  if (prevDotX < 0) return;
  // Repaint the background rectangle where the dot was
  // (recreate what drawStaticContent drew in that area)
  int x = prevDotX - DOT_SPRITE_W/2;
  int y = prevDotY - DOT_SPRITE_H/2;
  // Clamp to content zone
  x = constrain(x, 0, SCR_W - DOT_SPRITE_W);
  y = constrain(y, ZONE_CONTENT_Y, ZONE_FTR_Y - DOT_SPRITE_H);

  // Fill with background
  tft.fillRect(x, y, DOT_SPRITE_W, DOT_SPRITE_H, COL_BG);

  // Redraw any target circles that overlap this area
  // (check each circle centre against the erased rect)
  struct { int cx; int cy; int r; uint16_t col; } circles[] = {
    { 60, ZONE_CONTENT_Y+ 60, 30, COL_LABEL},
    {260, ZONE_CONTENT_Y+ 60, 30, COL_LABEL},
    { 60, ZONE_CONTENT_Y+120, 30, COL_LABEL},
    {260, ZONE_CONTENT_Y+120, 30, COL_LABEL},
    {160, ZONE_CONTENT_Y+ 82, 30, COL_ACCENT},
  };
  for (auto& c : circles) {
    // If circle overlaps erase rect, redraw it
    if (c.cx + c.r >= x && c.cx - c.r <= x + DOT_SPRITE_W &&
        c.cy + c.r >= y && c.cy - c.r <= y + DOT_SPRITE_H) {
      tft.drawCircle(c.cx, c.cy, c.r, c.col);
      tft.drawCircle(c.cx, c.cy, 5,   c.col);
    }
  }
  prevDotX = -1;
  prevDotY = -1;
}

void drawDot(int tx, int ty) {
  // Keep dot within content zone
  int sy = constrain(ty, ZONE_CONTENT_Y + DOT_SPRITE_H/2,
                         ZONE_FTR_Y    - DOT_SPRITE_H/2);
  int sx = constrain(tx, DOT_SPRITE_W/2, SCR_W - DOT_SPRITE_W/2);

  dot.fillSprite(COL_BG);   // Transparent-ish (matches background)
  dot.fillCircle(DOT_SPRITE_W/2, DOT_SPRITE_H/2, 12, activeColour);
  dot.drawCircle(DOT_SPRITE_W/2, DOT_SPRITE_H/2, 16, COL_TEXT);
  dot.pushSprite(sx - DOT_SPRITE_W/2, sy - DOT_SPRITE_H/2);

  prevDotX = sx;
  prevDotY = sy;
}

// ── Dynamic region 2 — coordinate text line ───────────────────────────────────
void updateCoordText(int tx, int ty, bool touched) {
  // Overwrite just the one text line — no sprite needed, background is solid
  tft.fillRect(0, COORD_TEXT_Y, SCR_W, 12, COL_BG);
  tft.setTextSize(1);
  if (touched) {
    tft.setTextColor(COL_TEXT, COL_BG);
    tft.setCursor(4, COORD_TEXT_Y);
    tft.printf("Touch X:%3d  Y:%3d", tx, ty);
  } else {
    tft.setTextColor(COL_LABEL, COL_BG);
    tft.setCursor(4, COORD_TEXT_Y);
    tft.print("Tap the display  |  Footer = colour");
  }
}

// ── Full screen rebuild (after calibration or setup) ─────────────────────────
void buildScreen() {
  drawStaticChrome();
  drawStaticContent();
  drawStaticFooter();
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T09 Touch Input FW:%s\n", FW_VERSION);

  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  pinMode(LED_RED,   OUTPUT); digitalWrite(LED_RED,   LOW);
  // LED_BLUE = GPIO 32 = MEMS_BCLK — safe in T09 (no I2S)
  pinMode(LED_BLUE,  OUTPUT); digitalWrite(LED_BLUE,  LOW);
  nextBtn.begin();

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);

  // Footer sprite only — no full-content sprite needed in this approach
  ftr.setColorDepth(16); ftr.createSprite(SCR_W, ZONE_FTR_H);
  // Small dot overlay sprite
  dot.setColorDepth(16); dot.createSprite(DOT_SPRITE_W, DOT_SPRITE_H);

  loadCalibration();
  buildScreen();

  digitalWrite(LED_GREEN, HIGH);
  Serial.println("Ready. Tap screen. NEXT long = calibrate.");
  Serial.println("Pattern: static regions drawn once, dynamic regions updated only on change.");
}

void loop() {
  Button::Event nextEv = nextBtn.read();

  if (nextEv == Button::LONG_PRESS) {
    runCalibration();
    buildScreen();
    return;
  }

  uint16_t tx, ty;
  bool touched = tft.getTouch(&tx, &ty);

  // ── Footer zone taps ────────────────────────────────────────────────────
  if (touched) {
    if (tzRed.isTapped(tx, ty, true)) {
      activeColour = COL_ERR;  activeZone = &tzRed;
      digitalWrite(LED_RED, HIGH); digitalWrite(LED_GREEN, LOW); digitalWrite(LED_BLUE, LOW);
      drawStaticFooter();
      Serial.printf("RED   X:%d Y:%d\n", tx, ty);
    } else if (tzGreen.isTapped(tx, ty, true)) {
      activeColour = COL_OK;   activeZone = &tzGreen;
      digitalWrite(LED_GREEN, HIGH); digitalWrite(LED_RED, LOW); digitalWrite(LED_BLUE, LOW);
      drawStaticFooter();
      Serial.printf("GREEN X:%d Y:%d\n", tx, ty);
    } else if (tzBlue.isTapped(tx, ty, true)) {
      activeColour = 0x001F;   activeZone = &tzBlue;
      digitalWrite(LED_BLUE, HIGH); digitalWrite(LED_RED, LOW); digitalWrite(LED_GREEN, LOW);
      drawStaticFooter();
      Serial.printf("BLUE  X:%d Y:%d\n", tx, ty);
    }
  }

  // ── Partial update: dot and text only when state changes ────────────────
  bool stateChanged = (touched != prevTouched)
                   || (touched && (tx != prevDotX || ty != prevDotY));

  if (stateChanged) {
    if (!touched && prevTouched) {
      // Finger lifted — erase dot, restore hint text
      eraseDot();
      updateCoordText(0, 0, false);
    } else if (touched && ty < ZONE_FTR_Y) {
      // Finger down or moving in content zone
      eraseDot();
      drawDot(tx, ty);
      updateCoordText(tx, ty, true);
    }
    prevTouched = touched;
  }

  delay(15);
}
