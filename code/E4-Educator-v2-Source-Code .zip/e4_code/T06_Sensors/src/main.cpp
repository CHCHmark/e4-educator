// T06 — One-wire and analog sensors
// DS18B20 non-blocking + LDR ADC1 averaging
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <OneWire.h>
#include <DallasTemperature.h>

Adafruit_AHTX0  aht;
OneWire          ow(ONE_WIRE);
DallasTemperature ds(&ow);

enum DS18St { DS18_IDLE, DS18_CONVERTING };
DS18St ds18State = DS18_IDLE;
unsigned long ds18Start = 0;
float ds18Temp = -99.0f;

int readLDR() {
  long t = 0;
  for (int i = 0; i < 8; i++) { t += analogRead(LDR); delay(2); }
  return constrain(map(t/8, 200, 3800, 0, 100), 0, 100);
}

void sensorsUpdate(unsigned long now) {
  switch (ds18State) {
    case DS18_IDLE:
      ds.requestTemperatures();
      ds18Start = now;
      ds18State = DS18_CONVERTING;
      break;
    case DS18_CONVERTING:
      if (now - ds18Start >= 750) {
        ds18Temp  = ds.getTempCByIndex(0);
        ds18State = DS18_IDLE;
      }
      break;
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  aht.begin(&Wire);
  ds.begin();
  ds.setResolution(12);
  ds.setWaitForConversion(false);
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, HIGH);
}

unsigned long lastPrint = 0;

void loop() {
  unsigned long now = millis();
  sensorsUpdate(now);
  if (now - lastPrint >= 2000) {
    lastPrint = now;
    sensors_event_t h, t;
    aht.getEvent(&h, &t);
    int ldr = readLDR();
    Serial.printf("AHT: %.1fC %.1f%%  DS18: %.1fC  LDR: %d%%\n",
                  t.temperature, h.relative_humidity, ds18Temp, ldr);
  }
}
