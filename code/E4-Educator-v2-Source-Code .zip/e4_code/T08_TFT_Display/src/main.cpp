// T08 — TFT Display and Sprite Pipeline
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - ILI9341 init, setRotation(0) = landscape 320x240
//   - Three-zone layout: Header Y0-34 / Content Y35-199 / Footer Y200-239
//   - TFT_eSprite double-buffer — zero flicker content updates
//   - Colour palette via COL_xxx defines
//   - NEXT button cycles four demo pages
//   - Page 0: animated counter + bouncing dot
//   - Page 1: colour swatches
//   - Page 2: text size demonstration
//   - Page 3: direct TFT primitives (shows why sprites are better)

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "Button.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_ERR     0xF800
#define COL_GRID    0x1082

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

TFT_eSPI    tft;
TFT_eSprite spr = TFT_eSprite(&tft);
Button      nextBtn(BTN_NEXT);

int currentPage = 0;
const int NUM_PAGES = 4;

void initTFT() {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8);
  ledcAttachPin(TFT_BL, 0);
  ledcWrite(0, 200);
  spr.setColorDepth(16);
  spr.createSprite(SCR_W, ZONE_CONTENT_H);
}

void drawChrome(const char* title) {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print(title);
  tft.setTextSize(1);
  tft.setTextColor(COL_LABEL, COL_HEADER);
  tft.setCursor(252, 14);
  tft.printf("FW:%s", FW_VERSION);

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(8, 214);
  tft.print("T08 TFT & Sprites  |  NEXT = next page");

  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawPage0(unsigned long now) {
  spr.fillSprite(COL_BG);
  for (int x = 40; x < SCR_W; x += 40) spr.drawFastVLine(x, 0, ZONE_CONTENT_H, COL_GRID);
  for (int y = 40; y < ZONE_CONTENT_H; y += 40) spr.drawFastHLine(0, y, SCR_W, COL_GRID);

  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(4);
  spr.setCursor(12, 16);
  spr.printf("%6lu s", now / 1000);

  int barW = (int)((now % 3000) * (long)SCR_W / 3000);
  uint16_t barCol = barW < SCR_W/3 ? COL_OK : barW < 2*SCR_W/3 ? COL_WARN : COL_ERR;
  spr.drawRect(0, 100, SCR_W, 20, COL_LABEL);
  spr.fillRect(1, 101, barW, 18, barCol);

  int dotX = (int)(SCR_W  * 0.5f + SCR_W  * 0.42f * sinf(now * 0.002f));
  int dotY = 148 + (int)(14.0f * cosf(now * 0.003f));
  spr.fillCircle(constrain(dotX, 8, SCR_W-8), dotY, 8, COL_ACCENT);

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 134);
  spr.print("Sprite push every loop() — no flicker");

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawPage1() {
  spr.fillSprite(COL_BG);
  struct { const char* name; uint16_t col; } sw[] = {
    {"COL_OK",COL_OK},{"COL_WARN",COL_WARN},{"COL_ERR",COL_ERR},{"COL_ACCENT",COL_ACCENT},
    {"COL_TEXT",COL_TEXT},{"COL_LABEL",COL_LABEL},{"COL_HEADER",COL_HEADER},{"COL_FOOTER",COL_FOOTER},
  };
  int swW = SCR_W/4, swH = ZONE_CONTENT_H/2;
  for (int i = 0; i < 8; i++) {
    int x = (i%4)*swW, y = (i/4)*swH;
    spr.fillRect(x, y, swW-2, swH-2, sw[i].col);
    spr.setTextColor(0xFFFF ^ sw[i].col, sw[i].col);
    spr.setTextSize(1);
    spr.setCursor(x+4, y+swH/2-4);
    spr.print(sw[i].name);
  }
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawPage2() {
  spr.fillSprite(COL_BG);
  spr.setTextColor(COL_TEXT, COL_BG);
  spr.setTextSize(1); spr.setCursor(4,  4); spr.print("Size 1: ABCDEF 0123456789 !@#$");
  spr.setTextSize(2); spr.setCursor(4, 20); spr.print("Size 2: ABCDEF 0123");
  spr.setTextSize(3); spr.setCursor(4, 46); spr.print("Size 3: ABCD");
  spr.setTextSize(4); spr.setCursor(4, 82); spr.print("Sz4: AB");
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 132);
  spr.printf("createSprite(%d, %d) — 16-bit colour", SCR_W, ZONE_CONTENT_H);
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 148);
  spr.printf("pushSprite(0, %d)", ZONE_CONTENT_Y);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawPage3() {
  // Direct TFT — no sprite, flicker visible during draw
  tft.fillRect(0, ZONE_CONTENT_Y, SCR_W, ZONE_CONTENT_H, COL_BG);
  tft.drawRect    (  8, ZONE_CONTENT_Y+8,  80, 40, COL_OK);
  tft.fillRect    ( 96, ZONE_CONTENT_Y+8,  80, 40, COL_WARN);
  tft.drawCircle  (280, ZONE_CONTENT_Y+35, 28, COL_ERR);
  tft.fillCircle  (200, ZONE_CONTENT_Y+60, 24, COL_ACCENT);
  tft.drawTriangle( 10, ZONE_CONTENT_Y+125, 50, ZONE_CONTENT_Y+65, 90, ZONE_CONTENT_Y+125, COL_TEXT);
  tft.fillTriangle(110, ZONE_CONTENT_Y+125,150, ZONE_CONTENT_Y+65,190, ZONE_CONTENT_Y+125, COL_LABEL);
  tft.drawRoundRect(210, ZONE_CONTENT_Y+65,100, 50, 10, COL_ACCENT);
  tft.setTextColor(COL_LABEL, COL_BG);
  tft.setTextSize(1);
  tft.setCursor(8, ZONE_CONTENT_Y+140);
  tft.print("Direct tft.draw...() — compare flicker to sprite");
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T08 TFT Display FW:%s\n", FW_VERSION);
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  nextBtn.begin();
  initTFT();
  drawChrome("T08  TFT & Sprite Pipeline");
  drawPage0(0);
  digitalWrite(LED_GREEN, HIGH);
  Serial.println("Ready — NEXT cycles pages 0-3");
}

void loop() {
  unsigned long now = millis();
  Button::Event ev = nextBtn.read();
  if (ev == Button::SHORT_PRESS) {
    currentPage = (currentPage + 1) % NUM_PAGES;
    const char* t[] = {
      "T08  Counter + Animation",
      "T08  Colour Palette",
      "T08  Text Sizes",
      "T08  Direct Primitives"
    };
    drawChrome(t[currentPage]);
    if (currentPage == 1) drawPage1();
    if (currentPage == 2) drawPage2();
    if (currentPage == 3) drawPage3();
    Serial.printf("Page %d\n", currentPage);
  }
  if (currentPage == 0) drawPage0(now);
  delay(16);
}
