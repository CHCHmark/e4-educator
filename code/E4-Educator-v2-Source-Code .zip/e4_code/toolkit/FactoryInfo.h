// FactoryInfo.h — E4 Educator v2.0
// Reads the factory test record written by E4_FACTORY_TEST firmware.
// Copy into src/ of any curriculum project that needs board identity.
//
// Usage:
//   FactoryInfo fi;
//   fi.load();
//   Serial.printf("SN: %s  Result: %s\n", fi.serial, fi.result);
//   mqtt.publish("e4/device/serial", fi.serial, true);
//
// The "factory" NVS namespace is NEVER cleared by Settings.h reset operations.
// It survives all OTA updates and factory resets of application settings.
// It is only overwritten by running E4_FACTORY_TEST again.

#pragma once
#include <Arduino.h>
#include <Preferences.h>

// ── NVS keys — must match E4_FACTORY_TEST exactly ──────────────────────────
#define FAC_NS        "factory"     //  7 chars ✓
#define FAC_SERIAL    "serial"      //  6 chars ✓
#define FAC_TEST_VER  "testFwVer"   //  9 chars ✓
#define FAC_TEST_DATE "testDate"    //  8 chars ✓
#define FAC_RESULT    "result"      //  6 chars ✓
#define FAC_PASS_CNT  "passCount"   //  9 chars ✓
#define FAC_FAIL_CNT  "failCount"   //  9 chars ✓
#define FAC_TIMESTAMP "testedMs"    //  8 chars ✓

struct FactoryInfo {
  char  serial[16]    = "UNSET";    // Board serial number e.g. "E4-000042"
  char  result[8]     = "UNKNOWN";  // "PASS", "FAIL", or "UNKNOWN"
  char  testFwVer[12] = "";         // Factory test firmware version
  char  testDate[12]  = "";         // Factory test build date
  int   passCount     = 0;
  int   failCount     = 0;
  unsigned long testedMs = 0;       // millis() at time of test completion
  bool  found         = false;      // true if NVS record exists

  // Load from NVS. Safe to call even if factory test has never been run —
  // returns defaults with found=false.
  void load() {
    Preferences p;
    p.begin(FAC_NS, true);  // read-only

    String s = p.getString(FAC_SERIAL, "");
    found = (s.length() > 0);

    if (found) {
      strncpy(serial,    s.c_str(),                        15);
      strncpy(result,    p.getString(FAC_RESULT,   "UNKNOWN").c_str(),  7);
      strncpy(testFwVer, p.getString(FAC_TEST_VER, "").c_str(),        11);
      strncpy(testDate,  p.getString(FAC_TEST_DATE,"").c_str(),        11);
      passCount = p.getInt(FAC_PASS_CNT, 0);
      failCount = p.getInt(FAC_FAIL_CNT, 0);
      testedMs  = p.getULong(FAC_TIMESTAMP, 0);
    }
    p.end();
  }

  // Print to Serial — useful in setup() for production diagnostics
  void print() const {
    if (!found) {
      Serial.println("[FactoryInfo] No factory test record found in NVS.");
      return;
    }
    Serial.println("[FactoryInfo] ─────────────────────────────");
    Serial.printf("  Serial number : %s\n",   serial);
    Serial.printf("  Test result   : %s\n",   result);
    Serial.printf("  Test firmware : %s  %s\n", testFwVer, testDate);
    Serial.printf("  Pass / Fail   : %d / %d\n", passCount, failCount);
    Serial.printf("  Test duration : %.1f seconds\n", testedMs / 1000.0f);
    Serial.println("[FactoryInfo] ─────────────────────────────");
  }

  // True if the board has a valid PASS factory record
  bool isPassed() const { return found && (strncmp(result, "PASS", 4) == 0); }

  // Publish factory identity to MQTT on startup.
  // Call after MQTT connects. Topics are retained so any new subscriber
  // immediately receives the current board identity without waiting.
  //
  // Topics published:
  //   e4/device/serial      — e.g. "E4-000042"
  //   e4/device/factoryTest — e.g. "PASS"
  //   e4/device/testFw      — e.g. "1.0.0"
  //
  // Usage:
  //   fi.publishMQTT(mqtt);
  template<typename MQTTClient>
  void publishMQTT(MQTTClient& mqtt) const {
    if (!found) return;
    mqtt.publish("e4/device/serial",      serial,     true);
    mqtt.publish("e4/device/factoryTest", result,     true);
    mqtt.publish("e4/device/testFw",      testFwVer,  true);
    Serial.printf("[FactoryInfo] Published to MQTT: SN=%s  FAT=%s\n",
                  serial, result);
  }
};
