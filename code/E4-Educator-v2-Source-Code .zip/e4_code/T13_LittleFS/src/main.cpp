// T13 — LittleFS
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - LittleFS.begin(true) — mount with format-on-fail
//   - ESPAsyncWebServer serving files from /data folder
//   - /api/sensors JSON endpoint
//   - JSON config file — read with ArduinoJson
//   - File browser page on TFT: list /data files
//   - ArduinoJson deserialize/serialize
// Upload data/ folder via: PlatformIO "Upload Filesystem Image"

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "Button.h"
#include "config.h"    // WiFi/MQTT credentials — edit this file

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_ERR     0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

TFT_eSPI       tft;
TFT_eSprite    spr  = TFT_eSprite(&tft);
Button         nextBtn(BTN_NEXT);
AsyncWebServer server(80);

bool fsOk      = false;
bool webOk     = false;
bool wifiOk    = false;
int  currentPage = 0;

// Simulated sensor values
float   tempC   = 22.4f;
float   humidity= 58.0f;
unsigned long readCount = 0;

void drawChrome(const char* title) {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print(title);
  tft.setTextSize(1);
  tft.setTextColor(fsOk ? COL_OK : COL_ERR, COL_HEADER);
  tft.setCursor(240, 9);
  tft.print(fsOk ? "FS OK" : "FS ERR");
  tft.setTextColor(wifiOk ? COL_OK : COL_LABEL, COL_HEADER);
  tft.setCursor(240, 22);
  tft.print(wifiOk ? "WiFi OK" : "No WiFi");

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 208);
  tft.print("T13 LittleFS  |  NEXT=view");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

// ── Page 0: file list ─────────────────────────────────────────────────────────
void drawFileList() {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setCursor(4, 4);
  spr.print("LittleFS /data contents:");

  if (!fsOk) {
    spr.setTextColor(COL_ERR, COL_BG);
    spr.setCursor(4, 20);
    spr.print("Filesystem not mounted.");
    spr.setCursor(4, 36);
    spr.print("Run: Upload Filesystem Image");
    spr.pushSprite(0, ZONE_CONTENT_Y);
    return;
  }

  File root = LittleFS.open("/");
  File f    = root.openNextFile();
  int  y    = 18, count = 0;
  while (f && y < ZONE_CONTENT_H - 14) {
    char buf[48];
    snprintf(buf, sizeof(buf), "%-30s %6u B", f.name(), f.size());
    spr.setTextColor(COL_TEXT, COL_BG);
    spr.setCursor(4, y);
    spr.print(buf);
    y += 14; count++;
    f = root.openNextFile();
  }
  root.close();

  if (count == 0) {
    spr.setTextColor(COL_LABEL, COL_BG);
    spr.setCursor(4, 20);
    spr.print("No files found.");
    spr.setCursor(4, 36);
    spr.print("Upload Filesystem Image first.");
  }

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, ZONE_CONTENT_H - 12);
  uint32_t used = LittleFS.usedBytes();
  uint32_t total = LittleFS.totalBytes();
  spr.printf("Used: %u / %u bytes", used, total);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── Page 1: web server status ─────────────────────────────────────────────────
void drawWebStatus() {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  auto row = [&](int y, const char* l, const String& v, uint16_t c=COL_TEXT) {
    spr.setTextColor(COL_LABEL, COL_BG); spr.setCursor(4,  y); spr.print(l);
    spr.setTextColor(c,         COL_BG); spr.setCursor(130, y); spr.print(v);
  };

  row(4,  "LittleFS:",   fsOk ? "Mounted OK" : "Mount failed", fsOk ? COL_OK : COL_ERR);
  row(18, "WiFi SSID:",  DEFAULT_SSID, wifiOk ? COL_OK : COL_LABEL);
  row(32, "IP address:", wifiOk ? WiFi.localIP().toString() : "Not connected");
  row(46, "Web server:", webOk ? "Running" : "Not started", webOk ? COL_OK : COL_LABEL);

  if (wifiOk) {
    spr.setTextColor(COL_ACCENT, COL_BG);
    spr.setCursor(4, 68);
    spr.printf("http://%s/", WiFi.localIP().toString().c_str());
    spr.setCursor(4, 82);
    spr.printf("http://%s/api/sensors", WiFi.localIP().toString().c_str());
  }

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 104);
  spr.print("Endpoints:");
  spr.setTextColor(COL_TEXT, COL_BG);
  spr.setCursor(4, 118); spr.print("GET /           index.html from LittleFS");
  spr.setCursor(4, 132); spr.print("GET /api/sensors  JSON sensor values");

  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setCursor(4, 152);
  spr.printf("Reads: %lu", readCount);

  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── JSON config read ──────────────────────────────────────────────────────────
void readConfig() {
  if (!fsOk) return;
  File f = LittleFS.open("/config.json", "r");
  if (!f) { Serial.println("config.json not found."); return; }
  StaticJsonDocument<256> doc;
  DeserializationError err = deserializeJson(doc, f);
  f.close();
  if (err) { Serial.printf("JSON parse error: %s\n", err.c_str()); return; }
  const char* ssid = doc["ssid"] | "not set";
  Serial.printf("Config: ssid=%s\n", ssid);
}

// ── Web server setup ───────────────────────────────────────────────────────────
void setupServer() {
  // Serve static files from LittleFS
  server.serveStatic("/", LittleFS, "/").setDefaultFile("index.html");

  // JSON API endpoint
  server.on("/api/sensors", HTTP_GET, [](AsyncWebServerRequest* req) {
    readCount++;
    // Update simulated values
    tempC    = 20.0f + 5.0f * sinf(millis() * 0.001f);
    humidity = 55.0f + 10.0f * cosf(millis() * 0.0007f);
    char json[80];
    snprintf(json, sizeof(json),
             "{\"temp\":%.1f,\"humid\":%.1f,\"reads\":%lu}",
             tempC, humidity, readCount);
    req->send(200, "application/json", json);
  });

  server.onNotFound([](AsyncWebServerRequest* req) {
    req->send(404, "text/plain", "Not found");
  });

  server.begin();
  webOk = true;
  Serial.printf("Web server started at http://%s\n",
                WiFi.localIP().toString().c_str());
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T13 LittleFS FW:%s\n", FW_VERSION);

  nextBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);

  // TFT init
  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  // LittleFS
  fsOk = LittleFS.begin(true);
  Serial.printf("LittleFS: %s\n", fsOk ? "OK" : "FAILED");
  if (fsOk) readConfig();

  // WiFi (non-blocking start)
  WiFi.mode(WIFI_STA);
  WiFi.begin(DEFAULT_SSID, DEFAULT_PASS);

  drawChrome("T13  LittleFS");
  drawFileList();
  digitalWrite(LED_GREEN, HIGH);
}

void loop() {
  static bool serverStarted = false;
  unsigned long now = millis();

  // Check WiFi
  bool wasOk = wifiOk;
  wifiOk = (WiFi.status() == WL_CONNECTED);
  if (wifiOk && !serverStarted) {
    setupServer();
    serverStarted = true;
  }
  if (wifiOk != wasOk) {
    drawChrome(currentPage == 0 ? "T13  File List" : "T13  Web Status");
  }

  Button::Event ev = nextBtn.read();
  if (ev == Button::SHORT_PRESS) {
    currentPage = (currentPage + 1) % 2;
    const char* t[] = {"T13  File List", "T13  Web Status"};
    drawChrome(t[currentPage]);
    if (currentPage == 0) drawFileList();
    else                  drawWebStatus();
  }

  // Refresh web status every 2s
  static unsigned long lastRefresh = 0;
  if (currentPage == 1 && now - lastRefresh >= 2000) {
    lastRefresh = now;
    drawWebStatus();
  }
}
