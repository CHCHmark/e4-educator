// P03 — Wireless Sensor Network — NODE
// Wake, read AHT20 + LDR + battery, transmit via ESP-NOW, deep sleep.
// Copy SensorPacket.h from toolkit/ into src/.
// Update MASTER_MAC_x and NODE_ID in platformio.ini before flashing.
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include "SensorPacket.h"

uint8_t masterMAC[] = {
  MASTER_MAC_0, MASTER_MAC_1, MASTER_MAC_2,
  MASTER_MAC_3, MASTER_MAC_4, MASTER_MAC_5
};

RTC_DATA_ATTR uint8_t  seqNum    = 0;
RTC_DATA_ATTR unsigned long totalWakes = 0;

Adafruit_AHTX0 aht;
volatile bool sendComplete = false, sendSuccess = false;

void onSent(const uint8_t* mac, esp_now_send_status_t status) {
  sendSuccess = (status == ESP_NOW_SEND_SUCCESS);
  sendComplete = true;
}

uint16_t readBatteryMv() {
  int raw = analogRead(BATT_ADC);
  return (uint16_t)((raw * 3300UL / 4095UL) * 2);
}

int readLDRPct() {
  long t = 0;
  for (int i = 0; i < 4; i++) { t += analogRead(LDR); delay(2); }
  return constrain(map(t/4, 200, 3800, 0, 100), 0, 100);
}

void setup() {
  Serial.begin(115200);
  totalWakes++;
  Serial.printf("Node %d wake #%lu\n", NODE_ID, totalWakes);

  Wire.begin(I2C_SDA, I2C_SCL);
  bool ahtOk = aht.begin(&Wire);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed — sleeping.");
    esp_deep_sleep(SLEEP_US); return;
  }
  esp_now_register_send_cb(onSent);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, masterMAC, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);

  SensorPacket pkt = {};
  pkt.magic     = PKT_MAGIC;
  pkt.version   = PKT_VERSION;
  pkt.nodeId    = NODE_ID;
  pkt.seqNum    = ++seqNum;
  pkt.uptimeSec = totalWakes * (SLEEP_US / 1000000UL);
  pkt.batteryMv = readBatteryMv();
  pkt.lightPct  = readLDRPct();

  if (ahtOk) {
    sensors_event_t h, t;
    aht.getEvent(&h, &t);
    pkt.tempC    = t.temperature;
    pkt.humidity = h.relative_humidity;
  } else {
    pkt.tempC = -99.0f; pkt.humidity = -99.0f;
  }
  pkt.crc = calcCRC((uint8_t*)&pkt, sizeof(pkt));

  esp_now_send(masterMAC, (uint8_t*)&pkt, sizeof(pkt));
  unsigned long t0 = millis();
  while (!sendComplete && millis() - t0 < 300) delay(5);

  Serial.printf("Seq:%d T:%.1f H:%.1f L:%d B:%dmV %s\n",
    pkt.seqNum, pkt.tempC, pkt.humidity,
    pkt.lightPct, pkt.batteryMv, sendSuccess ? "OK" : "FAIL");

  Serial.flush();
  esp_deep_sleep(SLEEP_US);
}

void loop() {}
