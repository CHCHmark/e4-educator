// P03 — Wireless Sensor Network — MASTER
// Receives ESP-NOW packets from up to 4 nodes.
// WIFI_AP_STA mode: ESP-NOW receiver + WiFi client for MQTT.
// See P03 document sections 4-7 for full implementation.
// Copy SensorPacket.h from toolkit/ into src/.
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include "config.h"    // WiFi/MQTT credentials — edit this file
// ... see P03 document for complete master implementation
void setup() { Serial.begin(115200); Serial.println("P03 Master — see document."); }
void loop()  { delay(5000); }
