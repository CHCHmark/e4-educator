// SensorPacket.h — Fundrum ESP-NOW standard sensor packet
// Copy into src/ of BOTH master and all node projects
// Must be byte-for-byte identical on all devices
#pragma once
#include <Arduino.h>

#define PKT_MAGIC       0xFD
#define PKT_VERSION     0x10
#define PKT_TYPE_SENSOR 0x01

struct __attribute__((packed)) SensorPacket {
  uint8_t  magic;        // Always PKT_MAGIC (0xFD)
  uint8_t  version;      // Protocol version (0x10)
  uint8_t  nodeId;       // Sender node ID (1-20)
  uint8_t  seqNum;       // Sequence number (wraps at 255)
  float    tempC;        // Temperature in Celsius
  float    humidity;     // Relative humidity %
  uint16_t lightPct;     // Light level 0-100%
  uint16_t batteryMv;    // Supply voltage in mV (0 = unknown)
  uint32_t uptimeSec;    // Node uptime / wake count * interval
  uint16_t crc;          // Checksum: sum of all preceding bytes
};
// Total: 22 bytes — well within 250-byte ESP-NOW limit

// Calculate CRC over all bytes except the last 2 (crc field)
inline uint16_t calcCRC(const uint8_t* data, size_t len) {
  uint16_t crc = 0;
  for (size_t i = 0; i < len - 2; i++) crc += data[i];
  return crc;
}

inline bool validateCRC(const SensorPacket& pkt) {
  return pkt.crc == calcCRC((uint8_t*)&pkt, sizeof(pkt));
}
