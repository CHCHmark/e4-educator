// T14 — OTA Firmware Updates (ElegantOTA)
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - ElegantOTA web-based firmware update at /update
//   - esp_ota_mark_app_valid_cancel_rollback() — 10s safety mark
//   - OTA progress bar on TFT
//   - Version display — proves new firmware ran after update
//   - min_spiffs.csv partition table required
//   - Filesystem image also uploadable via /update

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <ESPAsyncWebServer.h>
#include <ElegantOTA.h>
#include "Button.h"
#include "config.h"    // WiFi/MQTT credentials — edit this file

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_ERR     0xF800
#define COL_PROG    0x2E97   // Progress bar blue

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

TFT_eSPI       tft;
TFT_eSprite    spr = TFT_eSprite(&tft);
Button         nextBtn(BTN_NEXT);
AsyncWebServer server(80);

bool wifiOk    = false;
bool otaValid  = false;
bool otaActive = false;
int  otaPct    = 0;
unsigned long uptime = 0;

void drawOTAProgress(int pct) {
  spr.fillSprite(COL_BG);
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(2);
  spr.setCursor(8, 20);
  spr.print("OTA Update...");
  spr.setTextSize(1);
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(8, 48);
  spr.printf("Progress: %d%%", pct);

  // Progress bar
  spr.drawRect(8, 64, 300, 20, COL_LABEL);
  int w = (int)(pct * 298 / 100);
  if (w > 0) spr.fillRect(9, 65, w, 18, COL_PROG);

  spr.setTextColor(COL_WARN, COL_BG);
  spr.setCursor(8, 96);
  spr.print("Do not power off!");
  spr.setCursor(8, 112);
  spr.print("Board will restart automatically.");
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawChrome() {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print("T14  OTA Updates");
  tft.setTextSize(1);
  tft.setTextColor(otaValid ? COL_OK : COL_WARN, COL_HEADER);
  tft.setCursor(250, 9);
  tft.print(otaValid ? "App valid" : "Pending...");
  tft.setTextColor(wifiOk ? COL_OK : COL_LABEL, COL_HEADER);
  tft.setCursor(250, 22);
  tft.print(wifiOk ? "WiFi OK" : "No WiFi");

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 208);
  tft.print("T14 OTA  |  Browse to IP/update to flash");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void drawStatus() {
  spr.fillSprite(COL_BG);
  spr.setTextSize(1);

  auto row = [&](int y, const char* l, const String& v, uint16_t c=COL_TEXT) {
    spr.setTextColor(COL_LABEL, COL_BG); spr.setCursor(4,  y); spr.print(l);
    spr.setTextColor(c,         COL_BG); spr.setCursor(140, y); spr.print(v);
  };

  row(4,  "Firmware version:", FW_VERSION,  COL_ACCENT);
  row(18, "Build date:",       FW_DATE);
  row(32, "Uptime:",           String(millis()/1000) + " s");
  row(46, "OTA valid mark:",   otaValid ? "Set (10s passed)" : "Pending...",
                               otaValid ? COL_OK : COL_WARN);
  row(60, "WiFi SSID:",        DEFAULT_SSID, wifiOk ? COL_OK : COL_LABEL);
  row(74, "IP address:",       wifiOk ? WiFi.localIP().toString() : "---");

  if (wifiOk) {
    spr.setTextColor(COL_ACCENT, COL_BG);
    spr.setCursor(4, 96);
    spr.printf("OTA URL: http://%s/update",
               WiFi.localIP().toString().c_str());
    spr.setTextColor(COL_LABEL, COL_BG);
    spr.setCursor(4, 112);
    spr.print("Select firmware .bin to upload.");
    spr.setCursor(4, 126);
    spr.print("Build path: .pio/build/e4_educator_v2/firmware.bin");
  } else {
    spr.setTextColor(COL_WARN, COL_BG);
    spr.setCursor(4, 96);
    spr.print("Connecting to WiFi...");
  }

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 148);
  spr.print("Partition: min_spiffs.csv  (required for OTA)");
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T14 OTA FW:%s  Build:%s\n", FW_VERSION, FW_DATE);

  nextBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  LittleFS.begin(true);
  WiFi.mode(WIFI_STA);
  WiFi.begin(DEFAULT_SSID, DEFAULT_PASS);

  drawChrome();
  drawStatus();

  // ElegantOTA callbacks
  ElegantOTA.onStart([]() {
    otaActive = true;
    otaPct    = 0;
    Serial.println("[OTA] Start");
    drawChrome();
    drawOTAProgress(0);
  });

  ElegantOTA.onProgress([](size_t current, size_t total) {
    otaPct = (int)(current * 100 / total);
    drawOTAProgress(otaPct);
    Serial.printf("[OTA] %d%%\n", otaPct);
  });

  ElegantOTA.onEnd([](bool success) {
    Serial.printf("[OTA] End — %s\n", success ? "OK" : "FAIL");
    if (success) {
      spr.fillSprite(COL_BG);
      spr.setTextColor(COL_OK, COL_BG);
      spr.setTextSize(2);
      spr.setCursor(8, 60);
      spr.print("Update complete!");
      spr.setTextSize(1);
      spr.setTextColor(COL_LABEL, COL_BG);
      spr.setCursor(8, 92);
      spr.print("Rebooting...");
      spr.pushSprite(0, ZONE_CONTENT_Y);
    }
  });

  digitalWrite(LED_GREEN, HIGH);
}

void loop() {
  unsigned long now = millis();

  // WiFi check
  bool wasOk = wifiOk;
  wifiOk = (WiFi.status() == WL_CONNECTED);

  static bool serverStarted = false;
  if (wifiOk && !serverStarted) {
    serverStarted = true;
    ElegantOTA.begin(&server);
    server.begin();
    Serial.printf("OTA ready: http://%s/update\n",
                  WiFi.localIP().toString().c_str());
  }

  ElegantOTA.loop();

  // OTA validity mark — after 10s we know the app booted successfully
  if (!otaValid && now > 10000) {
    esp_ota_mark_app_valid_cancel_rollback();
    otaValid = true;
    Serial.println("App marked valid — OTA rollback cancelled.");
  }

  // Refresh display every 2s (not during OTA)
  static unsigned long lastDraw = 0;
  if (!otaActive && now - lastDraw >= 2000) {
    lastDraw = now;
    drawChrome();
    drawStatus();
  }

  delay(10);
}
