// T16 — I2S Audio and MEMS Microphone (ICS43434)
// E4 Educator v2.0 — Walark Electronics / Fundrum Engineering
// ============================================================
// Demonstrates:
//   - I2S driver setup for ICS43434 MEMS microphone
//   - Continuous audio capture via DMA
//   - RMS level calculation — dB SPL approximation
//   - FFT with arduinoFFT — dominant frequency detection
//   - Live waveform display on TFT
//   - Live spectrum bar display on TFT
//   - Volume meter page
//   - NOTE: GPIO 32 = MEMS_BCLK = LED_BLUE — LED_BLUE not used here

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <driver/i2s.h>
#include <arduinoFFT.h>
#include <math.h>
#include "Button.h"

#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_FOOTER  0x18C3
#define COL_TEXT    0xFFFF
#define COL_LABEL   0xC618
#define COL_ACCENT  0xFD20
#define COL_OK      0x07E0
#define COL_WARN    0xFFE0
#define COL_ERR     0xF800
#define COL_GRID    0x1082
#define COL_BAR_LO  0x07E0
#define COL_BAR_MID 0xFD20
#define COL_BAR_HI  0xF800

#define SCR_W          320
#define SCR_H          240
#define ZONE_HDR_Y       0
#define ZONE_HDR_H      35
#define ZONE_CONTENT_Y  35
#define ZONE_CONTENT_H 165
#define ZONE_FTR_Y     200
#define ZONE_FTR_H      40

#define FFT_SIZE     512
#define SAMPLE_RATE  16000
#define NUM_BARS      60

TFT_eSPI    tft;
TFT_eSprite spr = TFT_eSprite(&tft);
Button      nextBtn(BTN_NEXT);
Button      entBtn(BTN_ENT);

double  vReal[FFT_SIZE];
double  vImag[FFT_SIZE];
int32_t i2sBuf[FFT_SIZE];
arduinoFFT fft(vReal, vImag, FFT_SIZE, SAMPLE_RATE);

float bars[NUM_BARS]     = {};
float prevBars[NUM_BARS] = {};
float dBSPL       = 0;
float dominantHz  = 0;
int   currentPage = 0;
const int NUM_PAGES = 3;

// ── I2S init ─────────────────────────────────────────────────────────────────
void initI2S() {
  i2s_config_t cfg = {
    .mode             = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate      = SAMPLE_RATE,
    .bits_per_sample  = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format   = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count    = 4,
    .dma_buf_len      = FFT_SIZE / 2,
    .use_apll         = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk       = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num   = MEMS_BCLK,   // GPIO 32 — NOT used as LED_BLUE in this project
    .ws_io_num    = MEMS_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num  = MEMS_SD
  };
  i2s_driver_install(I2S_NUM_0, &cfg, 0, nullptr);
  i2s_set_pin(I2S_NUM_0, &pins);
  i2s_zero_dma_buffer(I2S_NUM_0);
  Serial.printf("I2S: BCLK=%d WS=%d SD=%d SR=%d\n",
                MEMS_BCLK, MEMS_WS, MEMS_SD, SAMPLE_RATE);
}

// ── Audio capture + process ───────────────────────────────────────────────────
void captureAndProcess() {
  size_t bytesRead = 0;
  i2s_read(I2S_NUM_0, i2sBuf,
           FFT_SIZE * sizeof(int32_t),
           &bytesRead, pdMS_TO_TICKS(50));

  int n = bytesRead / sizeof(int32_t);
  double rmsSum = 0;
  for (int i = 0; i < FFT_SIZE; i++) {
    double s = (i < n)
      ? (double)(i2sBuf[i] >> 8) / 8388608.0
      : 0.0;
    vReal[i] = s;
    vImag[i] = 0.0;
    rmsSum  += s * s;
  }

  float rms = sqrtf((float)(rmsSum / FFT_SIZE));
  // dB SPL approximation (ICS43434 sensitivity + 3.3V ADC offset)
  dBSPL = (rms > 0.000001f)
    ? 20.0f * log10f(rms / 0.000001f) + 30.0f
    : 0.0f;
  dBSPL = constrain(dBSPL, 0.0f, 100.0f);

  // FFT
  fft.windowing(FFT_WIN_TYP_HANN, FFT_FORWARD);
  fft.compute(FFT_FORWARD);
  fft.complexToMagnitude();
  dominantHz = (float)fft.majorPeak();

  // Map bins to bars with smoothing
  for (int b = 0; b < NUM_BARS; b++) {
    int bin = 2 + b * 2;
    if (bin + 1 >= FFT_SIZE / 2) break;
    double mag = (vReal[bin] + vReal[bin+1]) * 0.5;
    float dB   = (mag > 0.0) ? 20.0f * log10f((float)mag) : -80.0f;
    float h    = (float)map((long)constrain((int)dB, -80, -10), -80, -10, 0, ZONE_CONTENT_H);
    bars[b] = prevBars[b] * 0.3f + h * 0.7f;
    prevBars[b] = bars[b];
  }
}

// ── Render: spectrum bars ────────────────────────────────────────────────────
void drawSpectrum() {
  spr.fillSprite(COL_BG);
  for (int x = 0; x < SCR_W; x += 40) spr.drawFastVLine(x, 0, ZONE_CONTENT_H, COL_GRID);
  for (int y = 40; y < ZONE_CONTENT_H; y += 40) spr.drawFastHLine(0, y, SCR_W, COL_GRID);

  for (int i = 0; i < NUM_BARS; i++) {
    int h = constrain((int)bars[i], 0, ZONE_CONTENT_H);
    int x = i * 5;
    uint16_t col = (i < 15) ? COL_BAR_LO :
                   (i < 40) ? COL_BAR_MID : COL_BAR_HI;
    if (h > 0) spr.fillRect(x, ZONE_CONTENT_H - h, 4, h, col);
  }
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, ZONE_CONTENT_H - 12);
  spr.printf("Peak: %.0f Hz  |  dB: %.1f", dominantHz, dBSPL);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── Render: waveform ─────────────────────────────────────────────────────────
void drawWaveform() {
  spr.fillSprite(COL_BG);
  spr.drawFastHLine(0, ZONE_CONTENT_H/2, SCR_W, COL_GRID);

  // Plot 320 samples across the screen
  int step = FFT_SIZE / SCR_W;
  int prevY = ZONE_CONTENT_H / 2;
  for (int x = 0; x < SCR_W; x++) {
    int idx = x * step;
    if (idx >= FFT_SIZE) break;
    float s   = (float)(i2sBuf[idx] >> 8) / 8388608.0f;
    int   y   = (int)(ZONE_CONTENT_H/2 - s * ZONE_CONTENT_H * 0.4f);
    y = constrain(y, 0, ZONE_CONTENT_H - 1);
    spr.drawLine(x-1, prevY, x, y, COL_OK);
    prevY = y;
  }
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, ZONE_CONTENT_H - 12);
  spr.printf("%.1f dB SPL  |  %.0f Hz dominant", dBSPL, dominantHz);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

// ── Render: volume meter ─────────────────────────────────────────────────────
void drawVolume() {
  spr.fillSprite(COL_BG);
  spr.setTextColor(COL_ACCENT, COL_BG);
  spr.setTextSize(5);
  spr.setCursor(8, 10);
  spr.printf("%.0f", dBSPL);
  spr.setTextSize(2);
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(8, 75);
  spr.print("dB SPL");

  // Horizontal bar
  int bw = (int)map((long)dBSPL, 0, 100, 0, SCR_W - 10);
  bw = constrain(bw, 0, SCR_W - 10);
  uint16_t bc = dBSPL < 60 ? COL_OK : dBSPL < 80 ? COL_WARN : COL_ERR;
  spr.drawRect(5, 100, SCR_W - 10, 24, COL_LABEL);
  if (bw > 0) spr.fillRect(6, 101, bw, 22, bc);

  spr.setTextSize(1);
  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(5,  132); spr.print("0");
  spr.setCursor(155, 132); spr.print("50");
  spr.setCursor(305, 132); spr.print("100");

  spr.setTextColor(COL_LABEL, COL_BG);
  spr.setCursor(4, 152);
  spr.printf("Dominant: %.0f Hz  |  Peak hold: %.1f dB", dominantHz, dBSPL);
  spr.pushSprite(0, ZONE_CONTENT_Y);
}

void drawChrome(const char* title) {
  tft.fillRect(0, ZONE_HDR_Y, SCR_W, ZONE_HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 9);
  tft.print(title);
  tft.setTextSize(1);
  tft.setTextColor(COL_LABEL, COL_HEADER);
  tft.setCursor(262, 14);
  tft.printf("FW:%s", FW_VERSION);

  tft.fillRect(0, ZONE_FTR_Y, SCR_W, ZONE_FTR_H, COL_FOOTER);
  tft.setTextColor(COL_LABEL, COL_FOOTER);
  tft.setTextSize(1);
  tft.setCursor(4, 208);
  tft.print("T16 I2S Audio  |  NEXT=view  Speak/clap!");
  tft.drawFastHLine(0, ZONE_HDR_H,     SCR_W, COL_LABEL);
  tft.drawFastHLine(0, ZONE_FTR_Y - 1, SCR_W, COL_LABEL);
}

void setup() {
  Serial.begin(115200);
  Serial.printf("T16 I2S Audio FW:%s\n", FW_VERSION);
  Serial.println("NOTE: GPIO 32 = MEMS_BCLK — LED_BLUE NOT available in this project");

  nextBtn.begin(); entBtn.begin();
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  // NOTE: do NOT init LED_BLUE (GPIO 32) — shared with MEMS_BCLK

  pinMode(TFT_BL, OUTPUT); digitalWrite(TFT_BL, LOW);
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8); ledcAttachPin(TFT_BL, 0); ledcWrite(0, 200);
  spr.setColorDepth(16); spr.createSprite(SCR_W, ZONE_CONTENT_H);

  initI2S();
  drawChrome("T16  Spectrum");
  digitalWrite(LED_GREEN, HIGH);
  Serial.println("Ready — speak or clap near the microphone.");
}

void loop() {
  Button::Event ev = nextBtn.read();
  if (ev == Button::SHORT_PRESS) {
    currentPage = (currentPage + 1) % NUM_PAGES;
    const char* t[] = {"T16  Spectrum", "T16  Waveform", "T16  Volume"};
    drawChrome(t[currentPage]);
    Serial.printf("Page: %s\n", t[currentPage]);
  }

  // Audio capture and render: legitimately runs every loop pass
  // Real-time spectrum analysis requires continuous FFT frames (~20-30fps)
  // This is the correct exception to the partial-update rule —
  // when data changes every frame, you must redraw every frame
  captureAndProcess();

  switch (currentPage) {
    case 0: drawSpectrum(); break;
    case 1: drawWaveform(); break;
    case 2: drawVolume();   break;
  }
}
