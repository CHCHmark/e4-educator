// ============================================================================
// E4_FACTORY_TEST — E4 Educator v2.0 Board Acceptance Test
// Walark Electronics / Fundrum Engineering
// Tests every peripheral in sequence, reports PASS/FAIL on TFT and Serial.
// Final result written to SD card for production traceability.
// ============================================================================
// Usage:
//   AUTO mode   : Power on with both buttons released.
//                 Runs all automated tests, pauses for interactive tests.
//   MANUAL FAIL : During any interactive test, press ENT to force FAIL.
//   SKIP        : During any interactive test, press NEXT long to skip.
// ============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <TFT_eSPI.h>
#include <Adafruit_AHTX0.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <driver/i2s.h>
#include <Preferences.h>
#include <WiFi.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

#define OLED_W 128
#define OLED_H  64

// ── NVS factory namespace ─────────────────────────────────────────────────────
// Namespace "factory" is NEVER touched by curriculum firmware (Settings.h
// only clears "display", "alerts", "device", "network").
// Keys are all ≤15 characters — Fundrum NVS rule.
#define FAC_NS       "factory"      //  7 chars ✓
#define FAC_SERIAL   "serial"       //  6 chars ✓
#define FAC_TEST_VER "testFwVer"    //  9 chars ✓
#define FAC_TEST_DATE "testDate"    //  8 chars ✓
#define FAC_RESULT   "result"       //  6 chars ✓  "PASS" or "FAIL"
#define FAC_PASS_CNT "passCount"    //  9 chars ✓
#define FAC_FAIL_CNT "failCount"    //  9 chars ✓
#define FAC_TIMESTAMP "testedMs"    //  8 chars ✓

// Read serial number already stored from a previous test run (if any)
void nvsReadSerial(char* buf, size_t bufLen) {
  Preferences p;
  p.begin(FAC_NS, true);   // read-only
  String stored = p.getString(FAC_SERIAL, "");
  p.end();
  if (stored.length() > 0) {
    strncpy(buf, stored.c_str(), bufLen - 1);
    buf[bufLen - 1] = 0;
  }
}

// ── Test result store ─────────────────────────────────────────────────────────
#define MAX_TESTS 20

struct TestResult {
  const char* name;
  bool        ran;
  bool        passed;
  char        detail[40];  // Short pass/fail detail string
};

TestResult results[MAX_TESTS];
int        testCount = 0;
int        passCount = 0;
int        failCount = 0;

// ── Hardware objects ──────────────────────────────────────────────────────────
TFT_eSPI       tft;
TFT_eSprite    spr = TFT_eSprite(&tft);
Adafruit_AHTX0 aht;
OneWire        ow(ONE_WIRE);
DallasTemperature ds(&ow);

// ── Colour palette ────────────────────────────────────────────────────────────
#define COL_BG      0x0000
#define COL_HEADER  0x0319
#define COL_TEXT    0xFFFF
#define COL_PASS    0x07E0   // Green
#define COL_FAIL    0xF800   // Red
#define COL_TESTING 0xFFE0   // Yellow
#define COL_SKIP    0xC618   // Grey
#define COL_ACCENT  0xFD20   // Orange
#define COL_BORDER  0x2965   // Dim blue

// ── Board serial number (update per batch) ────────────────────────────────────
// Can be set via Serial command "SN:XXXXX" in first 3 seconds of boot
char boardSerial[16] = "E4-000001";

// ── TFT layout ───────────────────────────────────────────────────────────────
#define HDR_H      36
#define ROW_H      18        // Height per test row in result table
#define TABLE_Y    (HDR_H + 4)
#define TABLE_X    2
#define TABLE_W    236
#define VISIBLE_ROWS 13      // Rows visible on screen at once

int    scrollOffset = 0;     // Which test is at top of visible area

// ── Forward declarations ──────────────────────────────────────────────────────
void drawHeader();
void drawTable();
void drawRow(int idx, bool highlight);
void drawFinalScreen();
void recordResult(const char* name, bool passed, const char* detail);
bool waitForButton(unsigned long timeoutMs, bool& skipped);

// Write complete factory record to NVS after test completes
// (declared here, after boardSerial/passCount/failCount globals)
void nvsWriteFactoryRecord(bool passed) {
  Preferences p;
  p.begin(FAC_NS, false);  // read-write
  p.putString(FAC_SERIAL,    boardSerial);
  p.putString(FAC_TEST_VER,  FW_VERSION);
  p.putString(FAC_TEST_DATE, FW_DATE);
  p.putString(FAC_RESULT,    passed ? "PASS" : "FAIL");
  p.putInt(FAC_PASS_CNT,     passCount);
  p.putInt(FAC_FAIL_CNT,     failCount);
  p.putULong(FAC_TIMESTAMP,  millis());
  p.end();
  Serial.printf("[NVS] Factory record written — SN:%s  %s\n",
                boardSerial, passed ? "PASS" : "FAIL");
}

// ─────────────────────────────────────────────────────────────────────────────
// DISPLAY HELPERS
// ─────────────────────────────────────────────────────────────────────────────

void initTFT() {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, LOW);      // Safe init — always LOW before LEDC
  tft.init();
  // TFT rotation: 3 = landscape on most ILI9341 modules
  // If display is upside-down try rotation 1 instead
  // Touch rotation pairs: TFT rot 3 = touch rot 1  |  TFT rot 1 = touch rot 3
  tft.setRotation(3);
  tft.fillScreen(COL_BG);
  ledcSetup(0, 5000, 8);
  ledcAttachPin(TFT_BL, 0);
  ledcWrite(0, 220);
  spr.setColorDepth(16);
}

void drawHeader() {
  tft.fillRect(0, 0, 240, HDR_H, COL_HEADER);
  tft.setTextColor(COL_TEXT, COL_HEADER);
  tft.setTextSize(1);
  tft.setCursor(4, 4);
  tft.print("E4 EDUCATOR v2.0  FACTORY TEST");
  tft.setCursor(4, 16);
  tft.setTextColor(COL_ACCENT, COL_HEADER);
  tft.printf("SN: %-12s  FW: %s", boardSerial, FW_VERSION);
  tft.setCursor(4, 26);
  tft.setTextColor(COL_SKIP, COL_HEADER);
  tft.printf("P:%d  F:%d  Rem:%d", passCount, failCount,
             testCount - passCount - failCount);
}

void drawTable() {
  tft.fillRect(0, TABLE_Y, 240, 320 - TABLE_Y - 40, COL_BG);
  int visEnd = min(scrollOffset + VISIBLE_ROWS, testCount);
  for (int i = scrollOffset; i < visEnd; i++) {
    drawRow(i, false);
  }
}

void drawRow(int idx, bool highlight) {
  if (idx < 0 || idx >= testCount) return;
  int y = TABLE_Y + (idx - scrollOffset) * ROW_H;
  if (y < TABLE_Y || y + ROW_H > 278) return;

  TestResult& r = results[idx];
  uint16_t bg   = highlight  ? 0x0A29 : COL_BG;
  uint16_t numC = COL_SKIP;
  uint16_t stC  = COL_TESTING;
  const char* stStr = "...";

  if (r.ran) {
    stC   = r.passed ? COL_PASS : COL_FAIL;
    stStr = r.passed ? "PASS"   : "FAIL";
    numC  = stC;
  }

  tft.fillRect(TABLE_X, y, TABLE_W, ROW_H - 1, bg);

  // Index number
  tft.setTextColor(numC, bg);
  tft.setTextSize(1);
  tft.setCursor(TABLE_X + 1, y + 5);
  tft.printf("%02d", idx + 1);

  // Test name
  tft.setTextColor(COL_TEXT, bg);
  tft.setCursor(TABLE_X + 18, y + 5);
  tft.print(r.name);

  // Status badge
  tft.setTextColor(stC, bg);
  tft.setCursor(TABLE_X + 152, y + 5);
  tft.printf("%-4s", stStr);

  // Detail
  if (r.ran) {
    tft.setTextColor(COL_SKIP, bg);
    tft.setCursor(TABLE_X + 178, y + 5);
    // Truncate detail to fit
    char buf[12];
    strncpy(buf, r.detail, 11); buf[11] = 0;
    tft.print(buf);
  }

  // Divider line
  tft.drawFastHLine(TABLE_X, y + ROW_H - 1, TABLE_W, COL_BORDER);
}

void showTestBanner(const char* name, const char* instruction = nullptr) {
  // Overlay a banner at the bottom during interactive tests
  tft.fillRect(0, 200, 320, 40, COL_HEADER);
  tft.drawFastHLine(0, 200, 320, COL_ACCENT);
  tft.setTextColor(COL_ACCENT, COL_HEADER);
  tft.setTextSize(1);
  tft.setCursor(4, 284);
  tft.printf("TEST: %s", name);
  if (instruction) {
    tft.setTextColor(COL_TEXT, COL_HEADER);
    tft.setCursor(4, 296);
    tft.print(instruction);
    tft.setCursor(4, 308);
    tft.print("NEXT=PASS  ENT=FAIL  NEXT-long=SKIP");
  }
}

void recordResult(const char* name, bool passed, const char* detail) {
  if (testCount >= MAX_TESTS) return;
  results[testCount].name   = name;
  results[testCount].ran    = true;
  results[testCount].passed = passed;
  strncpy(results[testCount].detail, detail, 39);
  if (passed) passCount++; else failCount++;
  // Scroll table so latest result is visible
  if (testCount >= scrollOffset + VISIBLE_ROWS)
    scrollOffset = testCount - VISIBLE_ROWS + 1;
  drawRow(testCount, false);
  drawHeader();
  testCount++;
  Serial.printf("[%02d] %-26s %s  %s\n",
                testCount, name, passed ? "PASS" : "FAIL", detail);
  delay(80);  // Brief pause so operator can watch results accumulate
}

// Wait for NEXT (pass) or ENT (fail). Returns true=pass, false=fail.
// skipped=true if NEXT was held long.
bool waitForButton(unsigned long timeoutMs, bool& skipped) {
  skipped = false;
  unsigned long start = millis();
  bool nextLast = HIGH, entLast = HIGH;
  unsigned long nextPressTime = 0;

  while (millis() - start < timeoutMs) {
    bool nextNow = digitalRead(BTN_NEXT);
    bool entNow  = digitalRead(BTN_ENT);

    // NEXT pressed
    if (nextLast == HIGH && nextNow == LOW) {
      nextPressTime = millis();
    }
    // NEXT released
    if (nextLast == LOW && nextNow == HIGH) {
      unsigned long held = millis() - nextPressTime;
      if (held > 700) { skipped = true; return true; }  // Long = skip
      return true;   // Short = PASS
    }
    // ENT pressed and released = FAIL
    if (entLast == LOW && entNow == HIGH) return false;

    nextLast = nextNow;
    entLast  = entNow;
    delay(10);
  }
  // Timeout = auto-pass (for automated tests with no human prompt)
  return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// INDIVIDUAL TESTS
// ─────────────────────────────────────────────────────────────────────────────

// ── T01: LED sequence ─────────────────────────────────────────────────────────
void testLEDs() {
  const char* name = "LEDs RED/GRN/BLU";
  showTestBanner(name, "Watch LEDs: RED GREEN BLUE");

  // Each LED on for 400ms
  for (int pin : {LED_RED, LED_GREEN, LED_BLUE}) {
    digitalWrite(pin, HIGH);
    delay(400);
    digitalWrite(pin, LOW);
    delay(100);
  }
  // All on together
  digitalWrite(LED_RED,   HIGH);
  digitalWrite(LED_GREEN, HIGH);
  digitalWrite(LED_BLUE,  HIGH);
  delay(400);
  digitalWrite(LED_RED,   LOW);
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_BLUE,  LOW);

  bool skipped;
  bool pass = waitForButton(8000, skipped);
  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "All lit" : "FAIL"));
}

// ── T02: TFT backlight ramp ───────────────────────────────────────────────────
void testBacklight() {
  const char* name = "TFT Backlight PWM";
  showTestBanner(name, "Watch: dim -> bright -> dim");

  for (int b = 0; b <= 255; b += 5) { ledcWrite(0, b); delay(8); }
  delay(300);
  for (int b = 255; b >= 20; b -= 5) { ledcWrite(0, b); delay(8); }
  delay(300);
  ledcWrite(0, 220);  // Restore

  bool skipped;
  bool pass = waitForButton(6000, skipped);
  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "Ramp OK" : "FAIL"));
}

// ── T03: TFT colour fills ─────────────────────────────────────────────────────
void testTFTColours() {
  const char* name = "TFT Colour fills";
  showTestBanner(name, "Watch: RED GREEN BLUE WHITE BLACK");

  uint16_t colours[] = { TFT_RED, TFT_GREEN, TFT_BLUE, TFT_WHITE, TFT_BLACK };
  const char* cnames[] = { "RED", "GREEN", "BLUE", "WHITE", "BLACK" };
  for (int i = 0; i < 5; i++) {
    tft.fillRect(0, HDR_H, 240, 240, colours[i]);
    tft.setTextColor(colours[i] == TFT_BLACK ? TFT_WHITE : TFT_BLACK);
    tft.setTextSize(3);
    tft.setCursor(60, 130);
    tft.print(cnames[i]);
    delay(450);
  }
  tft.fillRect(0, HDR_H, 240, 240, COL_BG);
  drawTable();

  bool skipped;
  bool pass = waitForButton(6000, skipped);
  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "All colours" : "FAIL"));
}

// ── T04: Sprite pipeline ──────────────────────────────────────────────────────
void testSprite() {
  const char* name = "TFT Sprite pipeline";

  spr.createSprite(220, 60);
  bool ok = true;
  for (int i = 0; i < 8; i++) {
    spr.fillSprite(COL_BG);
    spr.setTextColor(COL_PASS, COL_BG);
    spr.setTextSize(3);
    spr.setCursor(4, 10);
    spr.printf("SPRITE %d", i);
    spr.drawRect(0, 0, 220, 60, COL_ACCENT);
    spr.pushSprite(10, 120);
    delay(80);
  }
  spr.deleteSprite();
  recordResult(name, ok, ok ? "No flicker" : "FAIL");
}

// ── T05: Touch XPT2046 ───────────────────────────────────────────────────────
void testTouch() {
  const char* name = "Touch XPT2046";

  // Quick raw read — just check we get non-zero values
  tft.fillRect(0, HDR_H, 240, 200, COL_BG);
  showTestBanner(name, "Tap screen anywhere");

  uint16_t tx, ty;
  unsigned long start = millis();
  bool touched = false;
  while (millis() - start < 10000) {
    if (tft.getTouch(&tx, &ty)) {
      touched = true;
      // Show where they touched
      tft.fillCircle(tx, ty, 8, COL_ACCENT);
      tft.setTextColor(COL_TEXT, COL_BG);
      tft.setTextSize(1);
      tft.setCursor(8, 250);
      tft.printf("Touch: X=%d Y=%d      ", tx, ty);
      delay(200);
    }
    // NEXT = pass once touched
    if (digitalRead(BTN_NEXT) == LOW && touched) {
      delay(50);
      while (digitalRead(BTN_NEXT) == LOW) delay(10);
      break;
    }
    // ENT = fail
    if (digitalRead(BTN_ENT) == LOW) {
      touched = false; break;
    }
  }
  tft.fillRect(0, HDR_H, 240, 200, COL_BG);
  drawTable();
  char detail[40];
  if (touched) snprintf(detail, sizeof(detail), "X=%d Y=%d", tx, ty);
  else strcpy(detail, "No touch");
  recordResult(name, touched, detail);
}

// ── T06: Buttons ──────────────────────────────────────────────────────────────
void testButtons() {
  // Test NEXT button
  {
    const char* name = "Button NEXT";
    showTestBanner(name, "Press NEXT button now");
    unsigned long start = millis();
    bool pressed = false;
    while (millis() - start < 8000) {
      if (digitalRead(BTN_NEXT) == LOW) { pressed = true; break; }
      if (digitalRead(BTN_ENT)  == LOW) { break; }
      delay(10);
    }
    while (digitalRead(BTN_NEXT) == LOW) delay(10);
    recordResult(name, pressed, pressed ? "Detected" : "Timeout");
    delay(300);
  }
  // Test ENT button
  {
    const char* name = "Button ENT";
    showTestBanner(name, "Press ENT button now");
    unsigned long start = millis();
    bool pressed = false;
    while (millis() - start < 8000) {
      if (digitalRead(BTN_ENT)  == LOW) { pressed = true; break; }
      if (digitalRead(BTN_NEXT) == LOW) { break; }  // Skip
      delay(10);
    }
    while (digitalRead(BTN_ENT) == LOW) delay(10);
    recordResult(name, pressed, pressed ? "Detected" : "Timeout");
    delay(300);
  }
}

// ── T07: I2C bus scan + AHT20 ────────────────────────────────────────────────
void testI2C() {
  Wire.begin(I2C_SDA, I2C_SCL);

  // Scan
  {
    const char* name = "I2C Bus scan";
    int found = 0;
    char devList[40] = "";
    for (uint8_t addr = 1; addr < 127; addr++) {
      Wire.beginTransmission(addr);
      if (Wire.endTransmission() == 0) {
        found++;
        char hex[8]; snprintf(hex, sizeof(hex), "0x%02X ", addr);
        strncat(devList, hex, sizeof(devList) - strlen(devList) - 1);
      }
    }
    char detail[40];
    snprintf(detail, sizeof(detail), "%d device(s): %s", found, devList);
    recordResult(name, found > 0, detail);
  }

  // AHT20
  {
    const char* name = "AHT20 sensor";
    bool ok = aht.begin(&Wire);
    char detail[40] = "Not found";
    if (ok) {
      sensors_event_t h, t;
      aht.getEvent(&h, &t);
      float temp  = t.temperature;
      float humid = h.relative_humidity;
      bool plausible = (temp > 5.0f && temp < 50.0f &&
                        humid > 5.0f && humid < 99.0f);
      ok = plausible;
      snprintf(detail, sizeof(detail), "%.1fC %.1f%%", temp, humid);
    }
    recordResult(name, ok, detail);
  }
}

// ── T08: DS18B20 ─────────────────────────────────────────────────────────────
void testDS18B20() {
  const char* name = "DS18B20 probe";
  ds.begin();
  int deviceCount = ds.getDeviceCount();
  char detail[40];
  bool ok = (deviceCount > 0);

  if (ok) {
    ds.requestTemperatures();
    delay(800);
    float t = ds.getTempCByIndex(0);
    ok = (t != DEVICE_DISCONNECTED_C && t > 5.0f && t < 80.0f);
    snprintf(detail, sizeof(detail), "%d dev  %.1fC", deviceCount, t);
  } else {
    strcpy(detail, "No device");
  }
  recordResult(name, ok, detail);
}

// ── T09: LDR (ADC1) ──────────────────────────────────────────────────────────
void testLDR() {
  const char* name = "LDR ADC1";
  showTestBanner(name, "Cover sensor then uncover");

  // Take ambient reading
  delay(200);
  int ambient = analogRead(LDR);

  // Ask operator to cover
  tft.fillRect(0, HDR_H, 240, 180, COL_BG);
  tft.setTextColor(COL_TEXT, COL_BG);
  tft.setTextSize(1);
  tft.setCursor(8, 120);
  tft.print("Cover LDR with finger...");
  delay(2500);
  int covered = analogRead(LDR);

  tft.setCursor(8, 135);
  tft.printf("Ambient:%d  Covered:%d", ambient, covered);

  // There should be a meaningful difference (>200 counts)
  int delta = abs(covered - ambient);
  bool ok = (delta > 200);
  char detail[40];
  snprintf(detail, sizeof(detail), "d=%d %s", delta, ok ? "OK" : "LOW");

  drawTable();
  recordResult(name, ok, detail);
}

// ── T10: Piezo buzzer ────────────────────────────────────────────────────────
void testPiezo() {
  const char* name = "Piezo buzzer";
  showTestBanner(name, "Listen: scale up then down");

  const int notes[] = {262, 330, 392, 523, 659, 784, 1047, 784, 659, 523, 392, 330, 262};
  const int nNotes  = sizeof(notes) / sizeof(notes[0]);

  for (int i = 0; i < nNotes; i++) {
    ledcSetup(1, notes[i], 8);
    ledcAttachPin(PIEZO, 1);
    ledcWrite(1, 128);
    delay(120);
    ledcWrite(1, 0);
    delay(30);
  }
  ledcDetachPin(PIEZO);

  bool skipped;
  bool pass = waitForButton(6000, skipped);
  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "Audible" : "Silent"));
}

// ── T11: DAC audio output ────────────────────────────────────────────────────
void testDAC() {
  const char* name = "DAC audio GPIO25";
  showTestBanner(name, "Listen/measure GPIO25 pin");

  // Build sine table
  uint8_t sineTable[256];
  for (int i = 0; i < 256; i++)
    sineTable[i] = (uint8_t)((sin(2.0 * PI * i / 256.0) + 1.0) * 127.5);

  // Play 440Hz sine for 1.5 seconds
  unsigned long stepUs = 1000000UL / (440 * 256);
  unsigned long endMs  = millis() + 1500;
  int idx = 0;
  while (millis() < endMs) {
    dacWrite(DAC_AUDIO, sineTable[idx]);
    idx = (idx + 1) & 0xFF;
    delayMicroseconds(stepUs);
  }
  dacWrite(DAC_AUDIO, 128);  // Midpoint

  bool skipped;
  bool pass = waitForButton(5000, skipped);
  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "Sine OK" : "No output"));
}

// ── T12: MEMS microphone (I2S) ───────────────────────────────────────────────
void testMEMSMic() {
  const char* name = "MEMS mic ICS43434";

  // NOTE: GPIO 32 (MEMS_BCLK) = LED_BLUE — must not have LEDC attached
  i2s_config_t cfg = {
    .mode             = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate      = 16000,
    .bits_per_sample  = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format   = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count    = 4,
    .dma_buf_len      = 64,
    .use_apll         = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk       = 0
  };
  i2s_pin_config_t pins = {
    .bck_io_num   = MEMS_BCLK,
    .ws_io_num    = MEMS_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num  = MEMS_SD
  };

  bool driverOk = (i2s_driver_install(I2S_NUM_0, &cfg, 0, nullptr) == ESP_OK);
  if (driverOk) i2s_set_pin(I2S_NUM_0, &pins);

  char detail[40] = "Driver fail";
  bool ok = false;

  if (driverOk) {
    showTestBanner(name, "Make noise (clap/speak)...");
    delay(500);

    int32_t buf[128];
    size_t  bytesRead = 0;
    i2s_read(I2S_NUM_0, buf, sizeof(buf), &bytesRead, pdMS_TO_TICKS(1000));

    double rmsSum = 0;
    int n = bytesRead / sizeof(int32_t);
    for (int i = 0; i < n; i++) {
      double s = (double)(buf[i] >> 8);
      rmsSum += s * s;
    }
    float rms = (n > 0) ? sqrtf((float)(rmsSum / n)) : 0;
    ok = (rms > 50.0f);  // Any meaningful signal above noise floor
    snprintf(detail, sizeof(detail), "RMS=%.0f %s", rms, ok ? "OK" : "LOW");

    i2s_driver_uninstall(I2S_NUM_0);
  }
  recordResult(name, ok, detail);
}

// ── T13: SD card ─────────────────────────────────────────────────────────────
void testSDCard() {
  // TFT already init — SD after TFT as per Fundrum rule
  const char* name = "SD card";
  bool mounted = SD.begin(SD_CS);
  char detail[40];

  if (!mounted) {
    recordResult(name, false, "Mount fail");
    return;
  }

  // Write test file
  const char* testPath = "/FACTTEST.TMP";
  const char* testData = "E4FACTTEST-OK";
  bool writeOk = false, readOk = false;

  File f = SD.open(testPath, FILE_WRITE);
  if (f) { f.print(testData); f.close(); writeOk = true; }

  f = SD.open(testPath);
  if (f) {
    String s = f.readString(); f.close();
    readOk = (s == testData);
    SD.remove(testPath);
  }

  unsigned long szMB = SD.cardSize() / (1024 * 1024);
  bool ok = writeOk && readOk;
  snprintf(detail, sizeof(detail), "%luMB W:%s R:%s",
           szMB, writeOk?"OK":"FAIL", readOk?"OK":"FAIL");
  recordResult(name, ok, detail);
}

// ── T14: WiFi scan ───────────────────────────────────────────────────────────
void testWiFi() {
  const char* name = "WiFi radio scan";
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);

  int n = WiFi.scanNetworks(false, true);  // Include hidden
  char detail[40];
  bool ok = (n > 0);
  if (n > 0) {
    // Show strongest network
    snprintf(detail, sizeof(detail), "%d nets RSSI=%ddBm", n, WiFi.RSSI(0));
  } else if (n == 0) {
    strcpy(detail, "No networks");
  } else {
    strcpy(detail, "Scan error");
  }
  WiFi.scanDelete();
  WiFi.mode(WIFI_OFF);
  recordResult(name, ok, detail);
}

// ── T15: OLED SSD1306 ────────────────────────────────────────────────────────
void testOLED() {
  const char* name = "OLED SSD1306";

  // Check I2C presence first — avoids hanging begin() if not fitted
  Wire.beginTransmission(0x3C);
  bool found = (Wire.endTransmission() == 0);

  if (!found) {
    // Not fitted — record informational, not a failure
    recordResult(name, true, "Not fitted");
    return;
  }

  // OLED present — actually drive it
  Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
  bool initOk = oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);

  if (!initOk) {
    recordResult(name, false, "Init failed");
    return;
  }

  showTestBanner(name, "Watch OLED: fill then text");

  // Test 1: full white fill
  oled.clearDisplay();
  oled.fillRect(0, 0, OLED_W, OLED_H, SSD1306_WHITE);
  oled.display();
  delay(600);

  // Test 2: full black fill
  oled.clearDisplay();
  oled.display();
  delay(400);

  // Test 3: text and border
  oled.clearDisplay();
  oled.drawRect(0, 0, OLED_W, OLED_H, SSD1306_WHITE);
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(4, 4);
  oled.print("E4 FACTORY TEST");
  oled.setCursor(4, 18);
  oled.print("OLED SSD1306 OK");
  oled.setCursor(4, 32);
  oled.printf("128x64  0x3C");
  oled.setCursor(4, 48);
  oled.print("NEXT=PASS  ENT=FAIL");
  oled.display();

  bool skipped;
  bool pass = waitForButton(8000, skipped);

  // Clear OLED before leaving
  oled.clearDisplay();
  oled.display();

  recordResult(name, pass, skipped ? "SKIPPED" : (pass ? "Display OK" : "FAIL"));
}

// ── T16: SPI bus coexistence ─────────────────────────────────────────────────
void testSPICoex() {
  const char* name = "SPI bus coexist";
  // TFT, touch, and SD all on VSPI — test that TFT still works after SD
  bool ok = true;
  spr.createSprite(200, 30);
  spr.fillSprite(COL_BG);
  spr.setTextColor(COL_PASS, COL_BG);
  spr.setTextSize(1);
  spr.setCursor(4, 10);
  spr.print("SPI coexistence OK");
  spr.pushSprite(20, 140);
  spr.deleteSprite();
  delay(300);
  tft.fillRect(20, 140, 200, 30, COL_BG);
  recordResult(name, ok, "TFT after SD");
}

// ─────────────────────────────────────────────────────────────────────────────
// FINAL SCREEN
// ─────────────────────────────────────────────────────────────────────────────

void drawFinalScreen() {
  bool allPass = (failCount == 0);

  tft.fillScreen(COL_BG);

  // Large PASS/FAIL
  uint16_t mainCol = allPass ? COL_PASS : COL_FAIL;
  tft.fillRect(0, 0, 240, 90, allPass ? 0x0320 : 0x2800);
  tft.setTextColor(mainCol);
  tft.setTextSize(5);
  tft.setCursor(allPass ? 28 : 20, 20);
  tft.print(allPass ? "PASS" : "FAIL");

  tft.setTextSize(1);
  tft.setTextColor(COL_TEXT);
  tft.setCursor(8, 78);
  tft.printf("SN: %s  FW: %s", boardSerial, FW_VERSION);

  // Score
  tft.setTextSize(2);
  tft.setCursor(8, 100);
  tft.setTextColor(COL_PASS);
  tft.printf("PASS: %d", passCount);
  tft.setCursor(8, 122);
  tft.setTextColor(failCount > 0 ? COL_FAIL : COL_SKIP);
  tft.printf("FAIL: %d", failCount);
  tft.setCursor(8, 144);
  tft.setTextColor(COL_SKIP);
  tft.printf("SKIP: %d", testCount - passCount - failCount);

  // Failed test list
  if (!allPass) {
    tft.setTextSize(1);
    tft.setCursor(8, 172);
    tft.setTextColor(COL_FAIL);
    tft.print("Failed tests:");
    int y = 184;
    for (int i = 0; i < testCount && y < 290; i++) {
      if (results[i].ran && !results[i].passed) {
        tft.setCursor(8, y);
        tft.setTextColor(COL_TEXT);
        tft.printf("  %02d %-20s %s", i+1, results[i].name, results[i].detail);
        y += 12;
      }
    }
  }

  // NVS confirmation line
  if (allPass) {
    tft.setTextSize(1);
    tft.setTextColor(COL_PASS, COL_BG);
    tft.setCursor(8, 278);
    tft.printf("\u2714 SN %s stored in NVS", boardSerial);
  }

  // Bottom bar
  tft.fillRect(0, 295, 240, 25, mainCol);
  tft.setTextColor(COL_BG, mainCol);
  tft.setTextSize(1);
  tft.setCursor(8, 302);
  tft.printf("Logged to SD + NVS  |  NEXT=restart");
}

void writeSDReport() {
  if (!SD.begin(SD_CS)) return;

  // Append to cumulative log
  File f = SD.open("/FACTORY_LOG.CSV", FILE_APPEND);
  if (!f) {
    // Create with header
    f = SD.open("/FACTORY_LOG.CSV", FILE_WRITE);
    if (!f) return;
    f.println("serial,fw,timestamp_ms,overall,passCount,failCount,details");
  }

  bool allPass = (failCount == 0);
  char line[120];
  snprintf(line, sizeof(line), "%s,%s,%lu,%s,%d,%d",
           boardSerial, FW_VERSION, millis(),
           allPass ? "PASS" : "FAIL", passCount, failCount);
  f.print(line);

  // Append failed test names
  for (int i = 0; i < testCount; i++) {
    if (results[i].ran && !results[i].passed) {
      f.print(",F:");
      f.print(results[i].name);
    }
  }
  f.println();
  f.close();

  // Also write a per-board detail file
  char fname[24];
  snprintf(fname, sizeof(fname), "/BOARD_%s.TXT", boardSerial);
  File fb = SD.open(fname, FILE_WRITE);
  if (fb) {
    fb.printf("E4 Educator v2.0 Factory Test Report\n");
    fb.printf("Board serial: %s\n", boardSerial);
    fb.printf("Firmware:     %s  %s\n", FW_VERSION, FW_DATE);
    fb.printf("Test time:    %lums\n", millis());
    fb.printf("Overall:      %s\n\n", allPass ? "PASS" : "FAIL");
    fb.printf("%-3s %-26s %-6s %s\n", "No.", "Test", "Result", "Detail");
    fb.printf("%-3s %-26s %-6s %s\n", "---", "---", "------", "------");
    for (int i = 0; i < testCount; i++) {
      fb.printf("%02d  %-26s %-6s %s\n",
                i+1, results[i].name,
                results[i].ran ? (results[i].passed ? "PASS" : "FAIL") : "---",
                results[i].detail);
    }
    fb.close();
  }

  Serial.printf("[SD] Report written: %s\n", fname);
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────

void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println("\n\n===========================================");
  Serial.printf("E4 Educator v2.0 Factory Test  FW:%s\n", FW_VERSION);
  Serial.println("===========================================");
  // Pre-load any serial number already stored in NVS from a previous test run.
  // Retests after rework automatically use the correct serial number.
  nvsReadSerial(boardSerial, sizeof(boardSerial));
  if (strlen(boardSerial) > 0) {
    Serial.printf("NVS serial found: %s  (send SN:XXXXX to override)\n", boardSerial);
  } else {
    strncpy(boardSerial, "E4-000001", sizeof(boardSerial));
    Serial.println("No NVS serial. Default: E4-000001  (send SN:XXXXX to set)");
  }

  Serial.println("Send SN:XXXXX within 3s to set or override serial number.");

  // Allow serial number to be set or overridden via Serial in first 3 seconds
  unsigned long snWindow = millis();
  while (millis() - snWindow < 3000) {
    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();
      if (cmd.startsWith("SN:")) {
        strncpy(boardSerial, cmd.substring(3).c_str(), 15);
        boardSerial[15] = 0;
        Serial.printf("Serial number set: %s\n", boardSerial);
      }
    }
  }

  // ── GPIO init — before anything else ──────────────────────────────────────
  pinMode(LED_RED,   OUTPUT); digitalWrite(LED_RED,   LOW);
  pinMode(LED_GREEN, OUTPUT); digitalWrite(LED_GREEN, LOW);
  pinMode(LED_BLUE,  OUTPUT); digitalWrite(LED_BLUE,  LOW);
  pinMode(BTN_NEXT,  INPUT_PULLUP);
  pinMode(BTN_ENT,   INPUT_PULLUP);

  // ── TFT FIRST — always ────────────────────────────────────────────────────
  initTFT();
  drawHeader();

  // Draw empty table
  tft.fillRect(0, TABLE_Y, 240, 240, COL_BG);
  tft.drawRect(TABLE_X, TABLE_Y, TABLE_W, VISIBLE_ROWS * ROW_H, COL_BORDER);

  // Column headers
  tft.setTextColor(COL_SKIP, COL_BG);
  tft.setTextSize(1);
  tft.setCursor(TABLE_X + 1,   TABLE_Y - 10);  tft.print("No");
  tft.setCursor(TABLE_X + 18,  TABLE_Y - 10);  tft.print("Test");
  tft.setCursor(TABLE_X + 152, TABLE_Y - 10);  tft.print("Result");
  tft.setCursor(TABLE_X + 178, TABLE_Y - 10);  tft.print("Detail");

  Serial.println("--- AUTOMATED TESTS BEGIN ---");

  // ─────────────────────────────────────────────────────────────────────────
  // RUN ALL TESTS IN ORDER
  // ─────────────────────────────────────────────────────────────────────────

  // Automated tests (no human interaction)
  testI2C();        // AHT20 + bus scan
  testDS18B20();    // One-wire probe
  testSDCard();     // SPI SD card (after TFT)
  testSPICoex();    // SPI bus coexistence
  testSprite();     // TFT sprite pipeline
  testWiFi();       // WiFi radio

  Serial.println("--- INTERACTIVE TESTS BEGIN ---");
  Serial.println("Operator: watch/listen/interact as prompted on TFT.");

  // Interactive tests (human confirmation required)
  testBacklight();  // Backlight PWM ramp
  testTFTColours(); // Colour fill sequence
  testLEDs();       // LED blink sequence
  testButtons();    // NEXT and ENT buttons
  testTouch();      // XPT2046 touch
  testLDR();        // LDR cover/uncover
  testPiezo();      // Piezo scale
  testDAC();        // DAC sine wave
  testMEMSMic();    // MEMS microphone

  // OLED — informational only (may not be fitted in all configurations)
  testOLED();

  // ─────────────────────────────────────────────────────────────────────────
  // RESULTS
  // ─────────────────────────────────────────────────────────────────────────

  Serial.println("\n===========================================");
  Serial.printf("FINAL RESULT: %s\n", failCount == 0 ? "PASS" : "FAIL");
  Serial.printf("Passed: %d / %d\n", passCount, testCount);
  if (failCount > 0) {
    Serial.println("Failed tests:");
    for (int i = 0; i < testCount; i++) {
      if (results[i].ran && !results[i].passed)
        Serial.printf("  - %s (%s)\n", results[i].name, results[i].detail);
    }
  }
  Serial.println("===========================================");

  // Write SD report
  writeSDReport();

  // Write factory record to NVS — persists permanently on this board
  // Survives power cycles, OTA updates, and Settings.h factory reset.
  // Curriculum firmware can read this via FactoryInfo.h
  bool allPassed = (failCount == 0);
  nvsWriteFactoryRecord(allPassed);

  // Show final screen (includes NVS confirmation)
  drawFinalScreen();

  // Status LED
  if (failCount == 0) {
    digitalWrite(LED_GREEN, HIGH);
  } else {
    digitalWrite(LED_RED, HIGH);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP — wait for NEXT to restart
// ─────────────────────────────────────────────────────────────────────────────

void loop() {
  // Blink status LED gently
  static unsigned long lastBlink = 0;
  static bool blinkState = false;
  if (millis() - lastBlink >= 800) {
    lastBlink = millis();
    blinkState = !blinkState;
    if (failCount == 0) {
      digitalWrite(LED_GREEN, blinkState ? HIGH : LOW);
    } else {
      digitalWrite(LED_RED, blinkState ? HIGH : LOW);
    }
  }

  // NEXT button = restart test
  if (digitalRead(BTN_NEXT) == LOW) {
    delay(50);
    while (digitalRead(BTN_NEXT) == LOW) delay(10);
    // Reset and restart
    testCount = passCount = failCount = 0;
    scrollOffset = 0;
    memset(results, 0, sizeof(results));
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_RED,   LOW);
    digitalWrite(LED_BLUE,  LOW);
    tft.fillScreen(COL_BG);
    ESP.restart();
  }
}
